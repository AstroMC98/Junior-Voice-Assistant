// Voice session — the hero screen.
// Variants: 'classic' | 'visual' | 'coach'

function ScreenSession({ guide, onClose, variant = 'classic', waveStyle = 'bars' }) {
  const [stepIdx, setStepIdx] = React.useState(2);
  const step = guide.steps[stepIdx] || guide.steps[0];
  const [listening, setListening] = React.useState(true);
  const [showImage, setShowImage] = React.useState(true);
  const [stepsOpen, setStepsOpen] = React.useState(false);
  const [photoOpen, setPhotoOpen] = React.useState(false);
  const [transcript, setTranscript] = React.useState(CONVERSATION);

  const next = () => setStepIdx(i => Math.min(i + 1, guide.steps.length - 1));
  const prev = () => setStepIdx(i => Math.max(i - 1, 0));

  const props = { guide, step, stepIdx, setStepIdx, listening, setListening,
    showImage, setShowImage, stepsOpen, setStepsOpen, photoOpen, setPhotoOpen,
    transcript, setTranscript, next, prev, onClose, waveStyle };

  return (
    <div style={{ width: '100%', height: '100%', position: 'relative', background: 'var(--bg)', overflow: 'hidden' }}>
      {variant === 'classic' && <SessionClassic {...props} />}
      {variant === 'visual'  && <SessionVisual  {...props} />}
      {variant === 'coach'   && <SessionCoach   {...props} />}

      {/* Steps drawer */}
      <Sheet open={stepsOpen} onClose={() => setStepsOpen(false)} height="78%">
        <StepsDrawer guide={guide} current={stepIdx} onPick={(i) => { setStepIdx(i); setStepsOpen(false); }} />
      </Sheet>

      {/* Photo progress check */}
      <Sheet open={photoOpen} onClose={() => setPhotoOpen(false)} height="74%">
        <PhotoCheck guide={guide} step={step} onClose={() => setPhotoOpen(false)} onPass={() => { setPhotoOpen(false); next(); }} />
      </Sheet>
    </div>
  );
}

// ── Shared chrome ──────────────────────────────────────────
function SessionHeader({ guide, stepIdx, total, onClose, onSteps, dark = false, transparent = false }) {
  return (
    <div style={{
      padding: '52px 16px 12px',
      background: transparent ? 'transparent' : 'var(--bg)',
      position: 'relative', zIndex: 4,
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        <button onClick={onClose} style={{
          width: 36, height: 36, borderRadius: 99,
          background: transparent ? 'rgba(0,0,0,0.35)' : 'var(--surface-2)',
          backdropFilter: 'blur(12px)',
          border: '1px solid', borderColor: transparent ? 'rgba(255,255,255,0.15)' : 'var(--border)',
          color: transparent ? '#fff' : 'var(--ink)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}><Ico.close/></button>
        <div style={{ flex: 1, minWidth: 0, color: transparent ? '#fff' : 'var(--ink)' }}>
          <div style={{ fontSize: 10, opacity: 0.7, marginBottom: 1, letterSpacing: 0.04 }} className="mono">
            VOICE SESSION
          </div>
          <div style={{ fontSize: 14, fontWeight: 600, letterSpacing: '-0.01em',
            whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
            {guide.title}
          </div>
        </div>
        <button onClick={onSteps} style={{
          height: 36, padding: '0 14px', borderRadius: 99,
          background: transparent ? 'rgba(0,0,0,0.35)' : 'var(--surface-2)',
          backdropFilter: 'blur(12px)',
          border: '1px solid', borderColor: transparent ? 'rgba(255,255,255,0.15)' : 'var(--border)',
          color: transparent ? '#fff' : 'var(--ink)',
          fontSize: 12, fontWeight: 600,
          display: 'flex', alignItems: 'center', gap: 6,
        }}>
          <Ico.list style={{width:16,height:16}}/>
          <span className="mono">{String(stepIdx + 1).padStart(2,'0')}/{String(total).padStart(2,'0')}</span>
        </button>
      </div>
      {/* progress dots */}
      <div style={{ marginTop: 12 }}>
        <StepProgress total={total} current={stepIdx}/>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Variant 1 — Classic
// ─────────────────────────────────────────────────────────────
function SessionClassic({ guide, step, stepIdx, listening, setListening,
  showImage, setShowImage, stepsOpen, setStepsOpen, photoOpen, setPhotoOpen,
  transcript, setTranscript, next, prev, onClose, waveStyle }) {

  return (
    <div style={{ width: '100%', height: '100%', display: 'flex', flexDirection: 'column' }}>
      <SessionHeader guide={guide} stepIdx={stepIdx} total={guide.steps.length}
        onClose={onClose} onSteps={() => setStepsOpen(true)} />

      <div style={{ flex: 1, overflowY: 'auto', padding: '8px 16px 8px' }}>
        {/* current step card */}
        <div className="fade-in" key={step.i} style={{
          background: 'var(--surface)', border: '1px solid var(--border)',
          borderRadius: 20, padding: 18, marginBottom: 14,
          boxShadow: 'var(--shadow-card)',
        }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
            <span className="tag tag-accent">
              <span className="stepnum">STEP {String(step.i).padStart(2,'0')}</span> · {guide.steps.length} total
            </span>
            <div style={{ fontSize: 11, color: 'var(--muted)' }} className="mono">
              ⌚ 04:23 elapsed
            </div>
          </div>
          <h2 style={{ margin: '0 0 8px', fontSize: 22, fontWeight: 600, letterSpacing: '-0.02em', lineHeight: 1.15 }}>
            {step.title}
          </h2>
          <p style={{ margin: 0, fontSize: 14.5, color: 'var(--ink-2)', lineHeight: 1.45 }}>
            {step.body}
          </p>

          {showImage && (
            <div style={{ marginTop: 14 }}>
              <StepImage guide={guide} step={step} height={170} />
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 8 }}>
                <div style={{ fontSize: 11, color: 'var(--muted)' }} className="mono">
                  📄 {guide.sourceLabel || 'source'} · p.{step.i}
                </div>
                <button onClick={() => setShowImage(false)} style={{ fontSize: 12, color: 'var(--muted)' }}>
                  Hide image
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Transcript */}
        <div style={{ marginBottom: 14 }}>
          <div style={{ fontSize: 11, color: 'var(--muted)', textTransform: 'uppercase', letterSpacing: 0.06, padding: '0 4px 8px', display: 'flex', justifyContent: 'space-between' }} className="mono">
            <span>TRANSCRIPT</span>
            <span>● LIVE</span>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {transcript.slice(-4).map((m, i) => <Bubble key={i} m={m}/>)}
          </div>
        </div>

        {/* Quick commands */}
        <QuickCommands onPick={(c) => setTranscript([...transcript, { role: 'user', t: '09:43:01', text: c }])} />
      </div>

      {/* Mic dock */}
      <MicDock listening={listening} setListening={setListening}
        onCamera={() => setPhotoOpen(true)} onPrev={prev} onNext={next}
        waveStyle={waveStyle} />
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Variant 2 — Visual-first (big image, minimal chrome)
// ─────────────────────────────────────────────────────────────
function SessionVisual({ guide, step, stepIdx, listening, setListening,
  setStepsOpen, setPhotoOpen, next, prev, onClose, waveStyle, transcript }) {

  const lastJ = [...transcript].reverse().find(m => m.role === 'junior');

  return (
    <div style={{ width: '100%', height: '100%', position: 'relative' }}>
      {/* Full-bleed image background */}
      <div style={{ position: 'absolute', inset: 0, background: guide.bg }}/>
      <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(180deg, rgba(0,0,0,0.45) 0%, rgba(0,0,0,0.2) 30%, rgba(0,0,0,0.85) 80%)' }}/>

      {/* a faux "page" floating */}
      <div style={{
        position: 'absolute', top: '20%', left: '8%', right: '8%',
        background: 'rgba(255,255,255,0.06)', backdropFilter: 'blur(12px)',
        borderRadius: 18, padding: 18, border: '1px solid rgba(255,255,255,0.12)',
      }}>
        <StepImage guide={guide} step={step} height={200} />
      </div>

      <SessionHeader guide={guide} stepIdx={stepIdx} total={guide.steps.length}
        onClose={onClose} onSteps={() => setStepsOpen(true)} transparent />

      {/* bottom area — step + transcript snippet + dock */}
      <div style={{
        position: 'absolute', bottom: 0, left: 0, right: 0,
        padding: '24px 20px 8px', color: '#fff',
      }}>
        <div className="fade-in" key={step.i} style={{ marginBottom: 14 }}>
          <div className="tag tag-accent" style={{ marginBottom: 8 }}>
            <span className="stepnum">STEP {String(step.i).padStart(2,'0')}</span>
          </div>
          <h2 style={{ margin: '0 0 6px', fontSize: 24, fontWeight: 600, letterSpacing: '-0.02em', lineHeight: 1.1 }}>
            {step.title}
          </h2>
          <p style={{ margin: 0, fontSize: 13.5, opacity: 0.85, lineHeight: 1.4,
            display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden' }}>
            {step.body}
          </p>
        </div>

        {lastJ && listening && (
          <div style={{
            background: 'rgba(255,255,255,0.1)', backdropFilter: 'blur(20px)',
            borderRadius: 14, padding: '10px 14px', marginBottom: 14,
            display: 'flex', gap: 10, alignItems: 'center',
          }}>
            <div style={{ width: 40, flexShrink: 0 }}>
              <Waveform active style="ring" height={20} bars={20} color="#fff"/>
            </div>
            <div style={{ fontSize: 12.5, opacity: 0.95, lineHeight: 1.35 }}>{lastJ.text}</div>
          </div>
        )}

        <MicDock listening={listening} setListening={setListening}
          onCamera={() => setPhotoOpen(true)} onPrev={prev} onNext={next}
          waveStyle={waveStyle} transparent />
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Variant 3 — Coach (chat-dominant)
// ─────────────────────────────────────────────────────────────
function SessionCoach({ guide, step, stepIdx, listening, setListening,
  setStepsOpen, setPhotoOpen, next, prev, onClose, waveStyle, transcript, setTranscript }) {

  const scrollRef = React.useRef(null);
  React.useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [transcript]);

  return (
    <div style={{ width: '100%', height: '100%', display: 'flex', flexDirection: 'column' }}>
      <SessionHeader guide={guide} stepIdx={stepIdx} total={guide.steps.length}
        onClose={onClose} onSteps={() => setStepsOpen(true)} />

      {/* sticky step header */}
      <div style={{
        margin: '0 16px 8px', padding: 12,
        background: 'var(--surface)', border: '1px solid var(--border)',
        borderRadius: 14, display: 'flex', gap: 10, alignItems: 'center',
      }}>
        <div style={{
          width: 36, height: 36, borderRadius: 10,
          background: 'var(--accent-soft)', color: 'var(--accent-ink)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontWeight: 600, fontSize: 13,
        }} className="stepnum">{String(step.i).padStart(2, '0')}</div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 13.5, fontWeight: 600, letterSpacing: '-0.01em' }}>{step.title}</div>
          <div style={{ fontSize: 11.5, color: 'var(--muted)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
            {step.body}
          </div>
        </div>
        <button onClick={prev} style={{ width: 28, height: 28, borderRadius: 99, background: 'var(--surface-2)', border: '1px solid var(--border)' }}>
          <Ico.chevL style={{ width: 14, height: 14 }}/>
        </button>
        <button onClick={next} style={{ width: 28, height: 28, borderRadius: 99, background: 'var(--surface-2)', border: '1px solid var(--border)' }}>
          <Ico.chev style={{ width: 14, height: 14 }}/>
        </button>
      </div>

      <div ref={scrollRef} style={{ flex: 1, overflowY: 'auto', padding: '8px 16px 12px', display: 'flex', flexDirection: 'column', gap: 10 }}>
        {transcript.map((m, i) => <Bubble key={i} m={m} large guide={guide} step={step}/>)}
        {listening && (
          <div style={{ alignSelf: 'flex-end', padding: '8px 14px', background: 'var(--accent-soft)', color: 'var(--accent-ink)',
            borderRadius: 18, borderBottomRightRadius: 4, fontSize: 13, display: 'flex', gap: 4 }}>
            <Dot d={0}/><Dot d={150}/><Dot d={300}/>
          </div>
        )}
      </div>

      <div style={{ padding: '0 16px 8px' }}>
        <QuickCommands compact onPick={(c) => setTranscript([...transcript, { role: 'user', t: '09:43:01', text: c }])} />
      </div>

      <MicDock listening={listening} setListening={setListening}
        onCamera={() => setPhotoOpen(true)} onPrev={prev} onNext={next}
        waveStyle={waveStyle} />
    </div>
  );
}

function Dot({ d }) {
  return <span style={{
    width: 6, height: 6, borderRadius: 99, background: 'currentColor', opacity: 0.5,
    animation: `typing 1.2s ${d}ms infinite`,
  }}/>;
}

// ─────────────────────────────────────────────────────────────
// Transcript bubble
// ─────────────────────────────────────────────────────────────
function Bubble({ m, large = false, guide, step }) {
  const isMe = m.role === 'user';
  const isAction = m.action === 'show_image';

  if (isAction && guide) {
    return (
      <div className="fade-in" style={{ alignSelf: 'flex-start', maxWidth: '90%', width: '100%' }}>
        <div style={{ fontSize: 10, color: 'var(--muted)', marginBottom: 4, padding: '0 4px' }} className="mono">
          JUNIOR · {m.t}
        </div>
        <div style={{
          padding: 12, background: 'var(--surface)', border: '1px solid var(--border)',
          borderRadius: 18, borderBottomLeftRadius: 4,
        }}>
          <div style={{ fontSize: 13.5, marginBottom: 10, color: 'var(--ink-2)' }}>{m.text}</div>
          <StepImage guide={guide} step={step} height={140} />
        </div>
      </div>
    );
  }

  return (
    <div className="fade-in" style={{
      alignSelf: isMe ? 'flex-end' : 'flex-start',
      maxWidth: '85%', display: 'flex', flexDirection: 'column', gap: 4,
    }}>
      <div style={{ fontSize: 10, color: 'var(--muted)', padding: '0 4px',
        textAlign: isMe ? 'right' : 'left' }} className="mono">
        {isMe ? 'YOU' : 'JUNIOR'} · {m.t}
      </div>
      <div style={{
        padding: large ? '10px 14px' : '8px 12px',
        background: isMe ? 'var(--accent)' : 'var(--surface)',
        color: isMe ? '#fff' : 'var(--ink-2)',
        borderRadius: 18,
        borderBottomRightRadius: isMe ? 4 : 18,
        borderBottomLeftRadius: isMe ? 18 : 4,
        border: isMe ? 0 : '1px solid var(--border)',
        fontSize: large ? 14 : 13.5, lineHeight: 1.4,
      }}>{m.text}</div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Quick commands
// ─────────────────────────────────────────────────────────────
function QuickCommands({ onPick, compact = false }) {
  return (
    <div>
      {!compact && (
        <div style={{ fontSize: 11, color: 'var(--muted)', textTransform: 'uppercase', letterSpacing: 0.06, padding: '0 4px 8px' }} className="mono">
          QUICK COMMANDS
        </div>
      )}
      <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
        {QUICK_CMDS.map(c => (
          <button key={c} onClick={() => onPick(c)}
            className="chip" style={{ height: 30, fontSize: 12, padding: '0 10px' }}>
            <span className="mono" style={{ fontSize: 9, opacity: 0.55, marginRight: 2 }}>›</span>{c}
          </button>
        ))}
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Mic dock — the centerpiece (with waveform)
// ─────────────────────────────────────────────────────────────
function MicDock({ listening, setListening, onCamera, onPrev, onNext, waveStyle, transparent = false }) {
  return (
    <div style={{
      padding: '14px 20px 20px',
      background: transparent ? 'transparent' :
        'linear-gradient(180deg, transparent, var(--bg) 30%)',
      display: 'flex', alignItems: 'center', gap: 14,
      position: 'relative', zIndex: 5,
    }}>
      <button onClick={onPrev} style={{
        width: 48, height: 48, borderRadius: 99, flexShrink: 0,
        background: transparent ? 'rgba(255,255,255,0.15)' : 'var(--surface)',
        border: '1px solid', borderColor: transparent ? 'rgba(255,255,255,0.2)' : 'var(--border)',
        color: transparent ? '#fff' : 'var(--ink)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        backdropFilter: 'blur(12px)',
      }}><Ico.chevL/></button>

      {/* mic + waveform */}
      <div style={{ flex: 1, position: 'relative', height: 60,
        background: transparent ? 'rgba(0,0,0,0.4)' : 'var(--surface)',
        border: '1px solid', borderColor: transparent ? 'rgba(255,255,255,0.15)' : 'var(--border)',
        borderRadius: 99,
        backdropFilter: 'blur(20px)',
        display: 'flex', alignItems: 'center', padding: '0 6px',
        boxShadow: transparent ? 'none' : 'var(--shadow-card)',
      }}>
        <button onClick={() => setListening(!listening)} className={listening ? 'pulse' : ''}
          style={{
            width: 48, height: 48, borderRadius: 99, flexShrink: 0,
            background: listening ? 'var(--accent)' : 'var(--surface-2)',
            color: listening ? '#fff' : 'var(--ink)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>
          {listening ? <Ico.micFill style={{width:22, height:22}}/> : <Ico.mic style={{width:22, height:22}}/>}
        </button>
        <div style={{ flex: 1, padding: '0 14px', height: 40, display: 'flex', alignItems: 'center' }}>
          <Waveform active={listening} style={waveStyle} height={36}
            color={transparent ? '#fff' : 'var(--accent)'} bars={22}/>
        </div>
        <div style={{ paddingRight: 14, fontSize: 11, opacity: 0.7, color: transparent ? '#fff' : 'var(--muted)' }} className="mono">
          {listening ? '● LIVE' : 'OFF'}
        </div>
      </div>

      <button onClick={onCamera} style={{
        width: 48, height: 48, borderRadius: 99, flexShrink: 0,
        background: transparent ? 'rgba(255,255,255,0.15)' : 'var(--surface)',
        border: '1px solid', borderColor: transparent ? 'rgba(255,255,255,0.2)' : 'var(--border)',
        color: transparent ? '#fff' : 'var(--ink)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        backdropFilter: 'blur(12px)',
      }}><Ico.camera/></button>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Steps drawer
// ─────────────────────────────────────────────────────────────
function StepsDrawer({ guide, current, onPick }) {
  return (
    <div style={{ padding: '4px 20px 20px' }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14 }}>
        <div>
          <div style={{ fontSize: 11, color: 'var(--muted)', textTransform: 'uppercase', letterSpacing: 0.06 }} className="mono">
            STEPS · {guide.title.toUpperCase()}
          </div>
          <div style={{ fontSize: 20, fontWeight: 600, letterSpacing: '-0.02em', marginTop: 2 }}>
            {guide.stepsCount} steps · {guide.duration}
          </div>
        </div>
        <div style={{ fontSize: 12, color: 'var(--muted)' }} className="mono">
          {current + 1} / {guide.steps.length}
        </div>
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 6, maxHeight: 480, overflowY: 'auto' }}>
        {guide.steps.map((s, i) => {
          const done = i < current;
          const now = i === current;
          return (
            <button key={s.i} onClick={() => onPick(i)} style={{
              display: 'flex', gap: 12, padding: 12,
              background: now ? 'var(--accent-soft)' : 'var(--surface)',
              border: '1px solid', borderColor: now ? 'var(--accent)' : 'var(--border)',
              borderRadius: 14, textAlign: 'left',
            }}>
              <div style={{
                width: 26, height: 26, borderRadius: 8,
                background: done ? 'var(--accent)' : now ? 'var(--accent)' : 'var(--surface-2)',
                color: done || now ? '#fff' : 'var(--ink)',
                border: '1px solid', borderColor: done || now ? 'transparent' : 'var(--border)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontSize: 11, fontWeight: 600, flexShrink: 0,
              }} className="stepnum">
                {done ? <Ico.check style={{width:13, height:13}}/> : String(s.i).padStart(2, '0')}
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 13.5, fontWeight: 600, letterSpacing: '-0.005em',
                  color: now ? 'var(--accent-ink)' : 'var(--ink)' }}>
                  {s.title}
                </div>
                <div style={{ fontSize: 12, color: now ? 'var(--accent-ink)' : 'var(--muted)', opacity: now ? 0.85 : 1, marginTop: 2,
                  display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden' }}>
                  {s.body}
                </div>
              </div>
              {now && <div className="tag tag-accent" style={{ height: 22, padding: '0 6px' }}>NOW</div>}
            </button>
          );
        })}
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Photo progress check
// ─────────────────────────────────────────────────────────────
function PhotoCheck({ guide, step, onClose, onPass }) {
  const [stage, setStage] = React.useState('capture'); // capture | review | result
  const [result, setResult] = React.useState(null);

  React.useEffect(() => {
    if (stage === 'review') {
      const t = setTimeout(() => {
        setResult({ pass: true,
          text: 'Looks correct. The yellow wire is cleanly severed and you haven\'t touched the others.',
          checks: [
            { ok: true,  l: 'Correct wire cut' },
            { ok: true,  l: 'No other wires damaged' },
            { ok: false, l: 'Module still attached firmly' },
          ],
        });
        setStage('result');
      }, 1800);
      return () => clearTimeout(t);
    }
  }, [stage]);

  return (
    <div style={{ padding: '4px 20px 20px' }}>
      <div style={{ fontSize: 11, color: 'var(--muted)', textTransform: 'uppercase', letterSpacing: 0.06 }} className="mono">
        PROGRESS CHECK · STEP {String(step.i).padStart(2,'0')}
      </div>
      <div style={{ fontSize: 20, fontWeight: 600, letterSpacing: '-0.02em', marginTop: 2, marginBottom: 14 }}>
        {step.title}
      </div>

      {stage === 'capture' && (
        <>
          <div style={{
            width: '100%', height: 280, borderRadius: 18,
            background: '#000', position: 'relative', overflow: 'hidden',
            border: '1px solid var(--border)',
          }}>
            <div style={{ position: 'absolute', inset: 0,
              background: 'radial-gradient(circle at center, #2a1810 0%, #000 100%)' }}/>
            {/* viewfinder */}
            {[
              { t: 12, l: 12, brT: 2, brL: 2 },
              { t: 12, r: 12, brT: 2, brR: 2 },
              { b: 12, l: 12, brB: 2, brL: 2 },
              { b: 12, r: 12, brB: 2, brR: 2 },
            ].map((p, i) => (
              <div key={i} style={{
                position: 'absolute', top: p.t, bottom: p.b, left: p.l, right: p.r,
                width: 22, height: 22,
                borderTop:    p.brT ? `${p.brT}px solid var(--accent)` : 0,
                borderBottom: p.brB ? `${p.brB}px solid var(--accent)` : 0,
                borderLeft:   p.brL ? `${p.brL}px solid var(--accent)` : 0,
                borderRight:  p.brR ? `${p.brR}px solid var(--accent)` : 0,
              }}/>
            ))}
            <div style={{ position: 'absolute', top: 14, left: '50%', transform: 'translateX(-50%)',
              fontSize: 11, color: 'rgba(255,255,255,0.8)' }} className="mono">
              ● 4K · 1/60
            </div>
            <div style={{ position: 'absolute', bottom: 16, left: 0, right: 0, textAlign: 'center',
              fontSize: 12, color: 'rgba(255,255,255,0.7)' }}>
              Hold steady — fit the module in view
            </div>
          </div>
          <button onClick={() => setStage('review')} className="btn btn-primary btn-lg btn-block" style={{ marginTop: 16 }}>
            <Ico.camera/> Capture & analyze
          </button>
        </>
      )}

      {stage === 'review' && (
        <div style={{ textAlign: 'center', padding: '20px 0' }}>
          <div style={{
            width: 80, height: 80, borderRadius: 20, margin: '0 auto 20px',
            background: 'var(--surface-2)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            animation: 'pulseRing 1.6s infinite',
          }}>
            <Ico.spark style={{width:32, height:32, color: 'var(--accent)'}}/>
          </div>
          <div style={{ fontSize: 16, fontWeight: 600 }}>Claude is analyzing the photo…</div>
          <div style={{ fontSize: 13, color: 'var(--muted)', marginTop: 4 }}>
            Comparing to step {step.i}: "{step.title}"
          </div>
        </div>
      )}

      {stage === 'result' && result && (
        <div className="fade-in">
          <div style={{
            padding: 14, borderRadius: 16,
            background: result.pass ? 'var(--accent-soft)' : '#FEE2E2',
            color: result.pass ? 'var(--accent-ink)' : '#7F1D1D',
            display: 'flex', gap: 12, alignItems: 'flex-start',
            marginBottom: 14,
          }}>
            <div style={{
              width: 32, height: 32, borderRadius: 99,
              background: result.pass ? 'var(--accent)' : '#DC2626',
              color: '#fff',
              display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
            }}>
              <Ico.check style={{width: 18, height: 18}}/>
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 14, fontWeight: 600, marginBottom: 4 }}>
                {result.pass ? 'Looks good — advance' : 'Try again'}
              </div>
              <div style={{ fontSize: 13, lineHeight: 1.4, opacity: 0.85 }}>{result.text}</div>
            </div>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 6, marginBottom: 16 }}>
            {result.checks.map((c, i) => (
              <div key={i} style={{ display: 'flex', gap: 8, fontSize: 13, alignItems: 'center' }}>
                <div style={{
                  width: 18, height: 18, borderRadius: 99,
                  background: c.ok ? 'var(--accent)' : 'var(--surface-3)',
                  color: c.ok ? '#fff' : 'var(--muted)',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  flexShrink: 0,
                }}>
                  {c.ok ? <Ico.check style={{width:11, height:11}}/> : '?'}
                </div>
                <span style={{ color: c.ok ? 'var(--ink)' : 'var(--muted)' }}>{c.l}</span>
              </div>
            ))}
          </div>
          <div style={{ display: 'flex', gap: 10 }}>
            <button onClick={onClose} className="btn btn-secondary btn-lg" style={{ flex: 1 }}>Retry</button>
            <button onClick={onPass} className="btn btn-primary btn-lg" style={{ flex: 1.5 }}>
              Advance <Ico.arrow style={{width:16,height:16}}/>
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

Object.assign(window, { ScreenSession });
