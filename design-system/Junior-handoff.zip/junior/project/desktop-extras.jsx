// Desktop: Guide Detail, Profile, Create

// ─── Guide Detail ──────────────────────────────────────────
function DTGuideDetail({ guide, onBack, onStart, onFork }) {
  return (
    <div>
      {/* Hero */}
      <div style={{
        position: 'relative', height: 360, background: guide.bg, overflow: 'hidden',
      }}>
        <div style={{
          position: 'absolute', inset: 0,
          background: 'linear-gradient(180deg, rgba(0,0,0,0.2) 0%, transparent 30%, rgba(0,0,0,0.7) 100%)',
        }}/>
        <button onClick={onBack} className="dt-btn dt-btn-ghost" style={{
          position: 'absolute', top: 24, left: 32, zIndex: 2,
          background: 'rgba(0,0,0,0.35)', color: '#fff', backdropFilter: 'blur(12px)',
        }}>
          <Ico.chevL/> Back
        </button>

        <div style={{
          position: 'absolute', top: 24, right: 32, zIndex: 2, display: 'flex', gap: 6,
        }}>
          {['share', 'fork', 'more'].map(key => (
            <button key={key} className="dt-iconbtn" style={{
              background: 'rgba(0,0,0,0.35)', color: '#fff', backdropFilter: 'blur(12px)',
            }}>
              {key === 'share' && <Ico.share/>}
              {key === 'fork' && <Ico.fork/>}
              {key === 'more' && <Ico.more/>}
            </button>
          ))}
        </div>

        <div style={{
          position: 'absolute', bottom: 28, left: 32, right: 32, color: '#fff', zIndex: 2,
          display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end',
        }}>
          <div style={{ display: 'flex', gap: 18, alignItems: 'flex-end' }}>
            <div style={{
              width: 80, height: 80, borderRadius: 18, background: 'rgba(255,255,255,0.12)',
              backdropFilter: 'blur(20px)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontSize: 44,
            }}>{guide.glyph}</div>
            <div>
              <div style={{ display: 'flex', gap: 6, marginBottom: 10 }}>
                <span className="tag" style={{ background: 'rgba(255,255,255,0.2)', color: '#fff', backdropFilter: 'blur(10px)' }}>
                  {CATEGORIES.find(c => c.id === guide.category)?.label}
                </span>
                <span className="tag" style={{ background: 'rgba(255,255,255,0.2)', color: '#fff', backdropFilter: 'blur(10px)' }}>
                  {guide.source.toUpperCase()}
                </span>
                <span className="tag" style={{ background: 'rgba(255,255,255,0.2)', color: '#fff', backdropFilter: 'blur(10px)' }}>
                  ★ {guide.rating}
                </span>
              </div>
              <h1 style={{
                margin: 0, fontFamily: 'var(--font-display)', fontSize: 40, fontWeight: 600,
                letterSpacing: '-0.025em', lineHeight: 1,
              }}>{guide.title}</h1>
              <p style={{ margin: '8px 0 0', fontSize: 15, opacity: 0.92, maxWidth: 600 }}>{guide.subtitle}</p>
            </div>
          </div>
          <div style={{ display: 'flex', gap: 8 }}>
            <button onClick={onFork} className="dt-btn dt-btn-lg" style={{
              background: 'rgba(255,255,255,0.15)', color: '#fff', backdropFilter: 'blur(12px)',
              border: '1px solid rgba(255,255,255,0.2)',
            }}>
              <Ico.fork/> Fork
            </button>
            <button onClick={onStart} className="dt-btn dt-btn-primary dt-btn-lg">
              <Ico.mic style={{width:16,height:16}}/> Start voice session
            </button>
          </div>
        </div>
      </div>

      {/* Body */}
      <div style={{ padding: '32px 32px', display: 'grid', gridTemplateColumns: '1fr 340px', gap: 32 }}>
        {/* Left — steps */}
        <div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12, marginBottom: 24 }}>
            {[
              { l: 'Steps', v: guide.stepsCount },
              { l: 'Time',  v: guide.duration },
              { l: 'Runs',  v: `${(guide.runs/1000).toFixed(1)}k` },
              { l: 'Forks', v: guide.forks },
            ].map((s, i) => (
              <div key={i} className="dt-stat">
                <div className="dt-stat-l">{s.l}</div>
                <div className="dt-stat-v">{s.v}</div>
              </div>
            ))}
          </div>

          <div style={{ marginBottom: 24 }}>
            <h3 className="dt-h2" style={{ fontSize: 15, marginBottom: 8 }}>About this guide</h3>
            <p style={{ fontSize: 14, lineHeight: 1.55, color: 'var(--ink-2)', margin: 0 }}>
              {guide.description}
            </p>
            <div style={{ display: 'flex', gap: 6, marginTop: 14, flexWrap: 'wrap' }}>
              {guide.tags?.map(t => (
                <span key={t} className="chip" style={{ height: 26, fontSize: 11.5 }}>#{t}</span>
              ))}
            </div>
          </div>

          <h3 className="dt-h2" style={{ fontSize: 15, marginBottom: 6 }}>
            {(() => {
              const hasSec = guide.steps.some(s => s.section);
              return hasSec ? 'Modules & steps' : 'Steps';
            })()}
            <span style={{ color: 'var(--muted)', fontWeight: 500, marginLeft: 6, fontSize: 13 }}>· {guide.stepsCount} total</span>
          </h3>
          {(() => {
            const hasSections = guide.steps.some(s => s.section);
            if (hasSections) return (
              <div style={{ fontSize: 12.5, color: 'var(--muted)', marginBottom: 16, lineHeight: 1.5 }}>
                Modules can be solved in any order. Junior routes you live based on what the Defuser describes.
              </div>
            );
            return null;
          })()}
          {(() => {
            const hasSections = guide.steps.some(s => s.section);
            if (!hasSections) {
              return (
                <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                  {guide.steps.map(step => <GuideStepRow key={step.i} step={step}/>)}
                </div>
              );
            }
            // group by section
            const groups = [];
            const seen = new Map();
            guide.steps.forEach(s => {
              const sec = s.section || 'Steps';
              if (!seen.has(sec)) { seen.set(sec, groups.length); groups.push({ name: sec, steps: [] }); }
              groups[seen.get(sec)].steps.push(s);
            });
            return (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
                {groups.map((g, gi) => {
                  const isSetup = g.name === 'Bomb intel';
                  const isFinal = g.name === 'Final';
                  const label = isSetup ? 'SETUP · DO FIRST' : isFinal ? 'FINAL CHECK' : 'MODULE · ANY ORDER';
                  return (
                    <div key={g.name}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 8 }}>
                        <div className="mono" style={{
                          fontSize: 10, letterSpacing: 0.08,
                          background: isSetup ? 'var(--surface-3)' : isFinal ? 'var(--surface-3)' : 'var(--accent-soft)',
                          color: isSetup || isFinal ? 'var(--muted)' : 'var(--accent-ink)',
                          padding: '3px 8px', borderRadius: 5, fontWeight: 600,
                        }}>{label}</div>
                        <h4 style={{ margin: 0, fontSize: 14, fontWeight: 600, letterSpacing: '-0.01em' }}>{g.name}</h4>
                        <span style={{ color: 'var(--muted)', fontSize: 12 }} className="mono">{g.steps.length} steps</span>
                      </div>
                      <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
                        {g.steps.map(step => <GuideStepRow key={step.i} step={step}/>)}
                      </div>
                    </div>
                  );
                })}
              </div>
            );
          })()}
        </div>

        {/* Right column */}
        <aside style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          {/* Author */}
          <div className="dt-card" style={{ padding: 18 }}>
            <div className="dt-eyebrow" style={{ marginBottom: 12 }}>CREATOR</div>
            <div style={{ display: 'flex', gap: 12, alignItems: 'center', marginBottom: 12 }}>
              <Avatar size={44} initials={guide.author.initials} color={guide.author.avatar}/>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 14, fontWeight: 600 }}>{guide.author.name}</div>
                <div style={{ fontSize: 12, color: 'var(--muted)' }}>132 followers · 14 guides</div>
              </div>
            </div>
            <button className="dt-btn dt-btn-secondary" style={{ width: '100%' }}>Follow</button>
          </div>

          {/* Source */}
          <div className="dt-card" style={{ padding: 18 }}>
            <div className="dt-eyebrow" style={{ marginBottom: 8 }}>SOURCE</div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 8 }}>
              {guide.source === 'pdf' && <Ico.pdf style={{color:'var(--accent)'}}/>}
              {guide.source === 'url' && <Ico.link style={{color:'var(--accent)'}}/>}
              {guide.source === 'camera' && <Ico.cam style={{color:'var(--accent)'}}/>}
              <div style={{ fontSize: 13.5, fontWeight: 500, fontFamily: 'var(--font-mono)' }}>
                {guide.sourceLabel || guide.source}
              </div>
            </div>
            <div style={{ fontSize: 12, color: 'var(--muted)', lineHeight: 1.4 }}>
              Processed by Claude on Apr 12, 2026. {guide.stepsCount} steps extracted, all with AI crop boxes.
            </div>
          </div>

          {/* Share */}
          <div className="dt-card" style={{ padding: 18 }}>
            <div className="dt-eyebrow" style={{ marginBottom: 10 }}>SHARE LINK</div>
            <div style={{
              padding: '10px 12px', background: 'var(--surface-2)', borderRadius: 8,
              display: 'flex', alignItems: 'center', gap: 8, fontSize: 12.5,
              fontFamily: 'var(--font-mono)', marginBottom: 10,
            }}>
              <Ico.link style={{width:14,height:14,color:'var(--muted)'}}/>
              <span style={{flex:1, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap'}}>
                junior.app/g/{guide.slug}
              </span>
            </div>
            <button className="dt-btn dt-btn-secondary" style={{ width: '100%' }}>
              <Ico.share/> Copy link
            </button>
          </div>

          {/* Reviews mini */}
          <div className="dt-card" style={{ padding: 18 }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
              <div className="dt-eyebrow">REVIEWS</div>
              <div style={{ fontSize: 13, fontWeight: 600 }}>★ {guide.rating} <span style={{ color: 'var(--muted)', fontWeight: 500 }}>· {(guide.runs/1000).toFixed(1)}k runs</span></div>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {[
                { who: 'Theo', text: 'Saved my Tuesday. The crop overlay is genuinely useful.', stars: 5 },
                { who: 'Mira', text: 'Forked it and added my own variations. Worked first try.', stars: 5 },
              ].map((r, i) => (
                <div key={i} style={{ fontSize: 12.5, color: 'var(--ink-2)', lineHeight: 1.4 }}>
                  <div style={{ fontWeight: 600 }}>{r.who} <span style={{ color: 'var(--accent)' }}>{'★'.repeat(r.stars)}</span></div>
                  <div style={{ color: 'var(--muted)' }}>"{r.text}"</div>
                </div>
              ))}
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
}

// ─── Profile ───────────────────────────────────────────────
function DTProfile({ onLogout, themeDark, onTheme, accent, onAccent }) {
  const [tab, setTab] = React.useState('account');
  const tabs = [
    { id: 'account',   label: 'Account' },
    { id: 'voice',     label: 'Voice & speech' },
    { id: 'appearance', label: 'Appearance' },
    { id: 'billing',   label: 'Billing' },
    { id: 'data',      label: 'Data & privacy' },
  ];

  return (
    <div className="dt-main-pad">
      <div style={{ marginBottom: 24 }}>
        <div className="dt-eyebrow">PROFILE</div>
        <h1 className="dt-h1">Settings</h1>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '220px 1fr', gap: 32, alignItems: 'flex-start' }}>
        {/* sidebar */}
        <aside style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
          {tabs.map(t => (
            <button key={t.id} onClick={() => setTab(t.id)} style={{
              padding: '10px 14px', borderRadius: 8,
              textAlign: 'left', fontSize: 13.5,
              background: tab === t.id ? 'var(--surface)' : 'transparent',
              border: tab === t.id ? '1px solid var(--border)' : '1px solid transparent',
              color: tab === t.id ? 'var(--ink)' : 'var(--muted)',
              fontWeight: tab === t.id ? 600 : 500,
            }}>
              {t.label}
            </button>
          ))}

          <div style={{ height: 1, background: 'var(--border)', margin: '16px 14px' }}/>
          <button onClick={onLogout} style={{
            padding: '10px 14px', borderRadius: 8, textAlign: 'left',
            fontSize: 13.5, color: '#DC2626', fontWeight: 500,
          }}>Sign out</button>
        </aside>

        {/* main */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 16, maxWidth: 720 }}>
          {tab === 'account' && (
            <>
              {/* Identity card */}
              <div className="dt-card" style={{ padding: 24 }}>
                <h3 className="dt-h2" style={{ marginBottom: 16 }}>Profile</h3>
                <div style={{ display: 'flex', gap: 18, alignItems: 'center', marginBottom: 20 }}>
                  <Avatar size={72} initials={ME.initials} color={ME.avatar}/>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: 18, fontWeight: 600, letterSpacing: '-0.01em' }}>{ME.name}</div>
                    <div style={{ fontSize: 13, color: 'var(--muted)' }}>{ME.email} · Member since {ME.joined}</div>
                    <div style={{ display: 'flex', gap: 6, marginTop: 8 }}>
                      <span className="tag tag-accent">{ME.plan.toUpperCase()}</span>
                      <span className="tag">{ME.guides} guides</span>
                      <span className="tag">{ME.followers} followers</span>
                    </div>
                  </div>
                  <button className="dt-btn dt-btn-secondary">Change avatar</button>
                </div>

                <DTFormRow label="Display name" value={ME.name}/>
                <DTFormRow label="Username" value="@sam" mono/>
                <DTFormRow label="Email" value={ME.email}/>
                <DTFormRow label="Bio" value="Cooks at home, repairs everything else." multi/>
              </div>

              <div className="dt-card" style={{ padding: 24 }}>
                <h3 className="dt-h2" style={{ marginBottom: 16 }}>Security</h3>
                <DTFormRow label="Password" value="••••••••••" action="Change"/>
                <DTFormRow label="Two-factor" value="Authenticator app" action="Manage"/>
                <DTFormRow label="Active sessions" value="3 devices" action="View" last/>
              </div>
            </>
          )}

          {tab === 'voice' && (
            <div className="dt-card" style={{ padding: 24 }}>
              <h3 className="dt-h2" style={{ marginBottom: 16 }}>Voice & speech</h3>
              <DTFormRow label="Junior's voice" value="Warm · en-US"
                hint="The voice you'll hear during sessions. Try a few to find your favourite."/>
              <DTFormRow label="Speech rate" value="1.0×" range/>
              <DTFormRow label="Wake word" value='"Hey Junior"'/>
              <DTFormRow label="Auto-listen on advance" value="On" toggle/>
              <DTFormRow label="Background noise suppression" value="Adaptive" last/>
            </div>
          )}

          {tab === 'appearance' && (
            <div className="dt-card" style={{ padding: 24 }}>
              <h3 className="dt-h2" style={{ marginBottom: 16 }}>Appearance</h3>

              {/* theme picker */}
              <div style={{ padding: '14px 0', borderBottom: '1px solid var(--border)' }}>
                <div style={{ fontSize: 13.5, fontWeight: 600, marginBottom: 4 }}>Theme</div>
                <div style={{ fontSize: 12.5, color: 'var(--muted)', marginBottom: 10 }}>Switch between light and dark.</div>
                <div className="seg" style={{ display: 'inline-flex' }}>
                  <button className={!themeDark ? 'on' : ''} onClick={() => onTheme(false)}>
                    <Ico.sun style={{width:14,height:14,marginRight:4}}/> Light
                  </button>
                  <button className={themeDark ? 'on' : ''} onClick={() => onTheme(true)}>
                    <Ico.moon style={{width:14,height:14,marginRight:4}}/> Dark
                  </button>
                </div>
              </div>

              {/* accent picker */}
              <div style={{ padding: '14px 0', borderBottom: '1px solid var(--border)' }}>
                <div style={{ fontSize: 13.5, fontWeight: 600, marginBottom: 4 }}>Accent color</div>
                <div style={{ fontSize: 12.5, color: 'var(--muted)', marginBottom: 10 }}>The highlight color used across the app.</div>
                <div style={{ display: 'flex', gap: 8 }}>
                  {[
                    { id: 'amber', label: 'Amber', color: '#F26B3A' },
                    { id: 'mint',  label: 'Mint',  color: '#2DBE7A' },
                    { id: 'iris',  label: 'Iris',  color: '#5B6CFF' },
                  ].map(c => (
                    <button key={c.id} onClick={() => onAccent(c.id)} style={{
                      padding: '8px 12px', borderRadius: 9,
                      border: '1px solid', borderColor: accent === c.id ? c.color : 'var(--border)',
                      background: accent === c.id ? c.color + '15' : 'var(--surface)',
                      display: 'flex', alignItems: 'center', gap: 8,
                      fontSize: 13, fontWeight: 500,
                    }}>
                      <span style={{ width: 16, height: 16, borderRadius: 99, background: c.color }}/>
                      {c.label}
                      {accent === c.id && <Ico.check style={{width:14,height:14,color:c.color}}/>}
                    </button>
                  ))}
                </div>
              </div>

              <DTFormRow label="Density" value="Comfortable"/>
              <DTFormRow label="Reduce motion" value="Off" toggle last/>
            </div>
          )}

          {tab === 'billing' && (
            <>
              <div className="dt-card" style={{ padding: 24, background: 'linear-gradient(135deg, var(--accent-soft), var(--surface))' }}>
                <div className="dt-eyebrow" style={{ color: 'var(--accent-ink)' }}>CURRENT PLAN</div>
                <h3 style={{ margin: '6px 0 4px', fontSize: 24, fontWeight: 600, letterSpacing: '-0.02em' }}>Pro</h3>
                <p style={{ margin: '0 0 14px', fontSize: 13, color: 'var(--accent-ink)', opacity: 0.85 }}>
                  $5/month · Unlimited guides, voice minutes, and team sharing.
                </p>
                <button className="dt-btn dt-btn-secondary">Manage subscription</button>
              </div>

              <div className="dt-card" style={{ padding: 24 }}>
                <h3 className="dt-h2" style={{ marginBottom: 16 }}>Usage this month</h3>
                <DTUsageBar label="Voice minutes" used={423} total={1000}/>
                <DTUsageBar label="Storage" used={142} total={5000} unit="MB"/>
                <DTUsageBar label="Guide processing" used={8} total={50}/>
              </div>

              <div className="dt-card" style={{ padding: 24 }}>
                <h3 className="dt-h2" style={{ marginBottom: 16 }}>Invoices</h3>
                {[
                  { date: 'May 1, 2026', amt: '$5.00', status: 'Paid' },
                  { date: 'Apr 1, 2026', amt: '$5.00', status: 'Paid' },
                  { date: 'Mar 1, 2026', amt: '$5.00', status: 'Paid' },
                ].map((inv, i) => (
                  <div key={i} style={{
                    display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                    padding: '12px 0',
                    borderBottom: i < 2 ? '1px solid var(--border)' : 0,
                  }}>
                    <div style={{ fontSize: 13.5 }}>{inv.date}</div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                      <span className="tag tag-accent" style={{ background: '#dcfce7', color: '#166534' }}>{inv.status}</span>
                      <span style={{ fontSize: 13.5, fontWeight: 600 }} className="mono">{inv.amt}</span>
                      <button className="dt-btn dt-btn-ghost" style={{ height: 28, fontSize: 12 }}>Download</button>
                    </div>
                  </div>
                ))}
              </div>
            </>
          )}

          {tab === 'data' && (
            <div className="dt-card" style={{ padding: 24 }}>
              <h3 className="dt-h2" style={{ marginBottom: 16 }}>Data & privacy</h3>
              <DTFormRow label="Voice transcripts retention" value="30 days"/>
              <DTFormRow label="Allow analytics" value="On" toggle/>
              <DTFormRow label="Export all data" value="" action="Request export"/>
              <DTFormRow label="Delete account" value="" action="Delete" danger last/>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function DTFormRow({ label, value, hint, action, toggle, range, mono, multi, last, danger }) {
  return (
    <div style={{
      padding: '14px 0',
      borderBottom: last ? 0 : '1px solid var(--border)',
      display: 'flex', gap: 24, alignItems: multi ? 'flex-start' : 'center',
    }}>
      <div style={{ width: 180, flexShrink: 0 }}>
        <div style={{ fontSize: 13.5, fontWeight: 600, color: danger ? '#DC2626' : 'var(--ink)' }}>{label}</div>
        {hint && <div style={{ fontSize: 11.5, color: 'var(--muted)', marginTop: 4, lineHeight: 1.4 }}>{hint}</div>}
      </div>
      <div style={{ flex: 1 }}>
        {toggle ? (
          <DTToggle on={value !== 'Off' && value !== 'off'} />
        ) : range ? (
          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <div style={{ flex: 1, height: 4, background: 'var(--surface-3)', borderRadius: 99, position: 'relative' }}>
              <div style={{ position: 'absolute', left: 0, top: 0, height: '100%', width: '40%', background: 'var(--accent)', borderRadius: 99 }}/>
              <div style={{ position: 'absolute', left: '40%', top: '50%', transform: 'translate(-50%, -50%)',
                width: 14, height: 14, borderRadius: 99, background: 'var(--surface)', border: '2px solid var(--accent)' }}/>
            </div>
            <span className="mono" style={{ fontSize: 12, fontWeight: 600, width: 40 }}>{value}</span>
          </div>
        ) : multi ? (
          <textarea defaultValue={value} style={{
            width: '100%', padding: '10px 12px',
            background: 'var(--surface-2)', border: '1px solid var(--border)',
            borderRadius: 8, fontSize: 13.5, color: 'var(--ink)',
            resize: 'vertical', minHeight: 60, outline: 'none', fontFamily: 'inherit',
          }} />
        ) : (
          <input defaultValue={value} style={{
            width: '100%', height: 36, padding: '0 12px',
            background: 'var(--surface-2)', border: '1px solid var(--border)',
            borderRadius: 8, fontSize: 13.5, color: 'var(--ink)',
            outline: 'none', fontFamily: mono ? 'var(--font-mono)' : 'inherit',
          }}/>
        )}
      </div>
      {action && (
        <button className={`dt-btn ${danger ? 'dt-btn-ghost' : 'dt-btn-secondary'}`}
          style={{ ...(danger ? { color: '#DC2626' } : {}) }}>{action}</button>
      )}
    </div>
  );
}

function DTToggle({ on }) {
  return (
    <div style={{
      width: 36, height: 20, borderRadius: 99, padding: 2,
      background: on ? 'var(--accent)' : 'var(--surface-3)',
      transition: 'background 0.15s',
    }}>
      <div style={{
        width: 16, height: 16, borderRadius: 99, background: '#fff',
        transform: `translateX(${on ? 16 : 0}px)`, transition: 'transform 0.15s',
        boxShadow: '0 1px 2px rgba(0,0,0,0.2)',
      }}/>
    </div>
  );
}

function DTUsageBar({ label, used, total, unit = '' }) {
  const pct = Math.min(100, (used / total) * 100);
  return (
    <div style={{ padding: '10px 0', borderBottom: '1px solid var(--border)' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13, marginBottom: 6 }}>
        <span>{label}</span>
        <span className="mono" style={{ color: 'var(--muted)' }}>{used}{unit} / {total}{unit}</span>
      </div>
      <div style={{ height: 6, background: 'var(--surface-3)', borderRadius: 99 }}>
        <div style={{ width: `${pct}%`, height: '100%', background: 'var(--accent)', borderRadius: 99 }}/>
      </div>
    </div>
  );
}

// ─── Create ────────────────────────────────────────────────
function DTCreate({ onBack, onCreated }) {
  const [source, setSource] = React.useState('pdf');
  const [stage, setStage] = React.useState('input');
  const [title, setTitle] = React.useState('');
  const [cat, setCat] = React.useState('cooking');

  React.useEffect(() => {
    if (stage === 'processing') {
      const t = setTimeout(() => setStage('done'), 3000);
      return () => clearTimeout(t);
    }
  }, [stage]);

  return (
    <div className="dt-main-pad" style={{ maxWidth: 980, margin: '0 auto' }}>
      <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', marginBottom: 24 }}>
        <div>
          <div className="dt-eyebrow">CREATE</div>
          <h1 className="dt-h1">New guide</h1>
          <div style={{ color: 'var(--muted)', fontSize: 14, marginTop: 4 }}>Junior reads any document and turns it into a hands-free voice session.</div>
        </div>
        <button onClick={onBack} className="dt-btn dt-btn-ghost"><Ico.close style={{width:16,height:16}}/> Cancel</button>
      </div>

      {/* Progress steps */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 28 }}>
        {['Source', 'Process', 'Review', 'Publish'].map((s, i) => {
          const idx = stage === 'input' ? 0 : stage === 'processing' ? 1 : stage === 'done' ? 2 : 0;
          const done = i < idx;
          const now = i === idx;
          return (
            <React.Fragment key={s}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <div style={{
                  width: 26, height: 26, borderRadius: 99,
                  background: done ? 'var(--accent)' : now ? 'var(--accent-soft)' : 'var(--surface-2)',
                  border: '1px solid', borderColor: done || now ? 'var(--accent)' : 'var(--border)',
                  color: done ? '#fff' : now ? 'var(--accent-ink)' : 'var(--muted)',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontSize: 12, fontWeight: 600,
                }} className="mono">
                  {done ? <Ico.check style={{width:13,height:13}}/> : i + 1}
                </div>
                <span style={{ fontSize: 13, fontWeight: now ? 600 : 500, color: now ? 'var(--ink)' : 'var(--muted)' }}>{s}</span>
              </div>
              {i < 3 && <div style={{ flex: 1, height: 1, background: done ? 'var(--accent)' : 'var(--border)' }}/>}
            </React.Fragment>
          );
        })}
      </div>

      {stage === 'input' && (
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 320px', gap: 24 }}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>
            <div className="dt-card" style={{ padding: 24 }}>
              <h3 className="dt-h2" style={{ marginBottom: 16 }}>1 · Source</h3>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 10 }}>
                {[
                  { id: 'pdf', label: 'PDF', icon: <Ico.pdf/>, hint: 'Upload a document.' },
                  { id: 'url', label: 'URL', icon: <Ico.link/>, hint: 'Paste a web link.' },
                  { id: 'cam', label: 'Camera', icon: <Ico.cam/>, hint: 'Photograph pages.' },
                ].map(s => (
                  <button key={s.id} onClick={() => setSource(s.id)} style={{
                    padding: 16,
                    background: source === s.id ? 'var(--accent-soft)' : 'var(--surface-2)',
                    border: '1px solid', borderColor: source === s.id ? 'var(--accent)' : 'var(--border)',
                    borderRadius: 10,
                    display: 'flex', flexDirection: 'column', alignItems: 'flex-start', gap: 6,
                    color: source === s.id ? 'var(--accent-ink)' : 'var(--ink)',
                    textAlign: 'left',
                  }}>
                    <div style={{ color: source === s.id ? 'var(--accent)' : 'var(--muted)' }}>{s.icon}</div>
                    <div style={{ fontSize: 13, fontWeight: 600 }}>{s.label}</div>
                    <div style={{ fontSize: 11.5, opacity: 0.7 }}>{s.hint}</div>
                  </button>
                ))}
              </div>

              {/* dropzone */}
              {source === 'pdf' && (
                <div style={{
                  marginTop: 16, padding: '36px 24px',
                  border: '1.5px dashed var(--border-strong)',
                  borderRadius: 12, textAlign: 'center', background: 'var(--surface-2)',
                }}>
                  <div style={{ fontSize: 36, marginBottom: 6 }}>📄</div>
                  <div style={{ fontSize: 14.5, fontWeight: 600, marginBottom: 4 }}>Drop a PDF here</div>
                  <div style={{ fontSize: 12.5, color: 'var(--muted)', marginBottom: 14 }}>Up to 50 MB · scanned PDFs supported</div>
                  <button className="dt-btn dt-btn-secondary">Choose file</button>
                </div>
              )}
              {source === 'url' && (
                <div style={{ marginTop: 16, display: 'flex', gap: 8 }}>
                  <input placeholder="https://bombmanual.com" style={{
                    flex: 1, height: 42, padding: '0 14px',
                    background: 'var(--surface-2)', border: '1px solid var(--border)',
                    borderRadius: 10, fontSize: 14, outline: 'none',
                  }}/>
                  <button className="dt-btn dt-btn-secondary">Fetch</button>
                </div>
              )}
              {source === 'cam' && (
                <div style={{
                  marginTop: 16, padding: 18, background: 'var(--surface-2)',
                  border: '1px solid var(--border)', borderRadius: 10,
                  display: 'flex', gap: 14, alignItems: 'center',
                }}>
                  <div style={{
                    width: 60, height: 60, borderRadius: 10,
                    background: 'linear-gradient(135deg, #18181b, #3f3f46)',
                    display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff',
                  }}><Ico.camera/></div>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: 14, fontWeight: 600 }}>Photograph the manual</div>
                    <div style={{ fontSize: 12.5, color: 'var(--muted)', marginTop: 2 }}>Up to 30 pages, well-lit.</div>
                  </div>
                  <button className="dt-btn dt-btn-secondary">Open camera</button>
                </div>
              )}
            </div>

            <div className="dt-card" style={{ padding: 24 }}>
              <h3 className="dt-h2" style={{ marginBottom: 16 }}>2 · Describe it</h3>
              <DTFormRow label="Title" value="" hint="What is this guide?"/>
              <DTFormRow label="Description" value="" multi/>
              <div style={{ padding: '14px 0' }}>
                <div style={{ display: 'flex', gap: 24, alignItems: 'center' }}>
                  <div style={{ width: 180, flexShrink: 0 }}>
                    <div style={{ fontSize: 13.5, fontWeight: 600 }}>Category</div>
                  </div>
                  <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', flex: 1 }}>
                    {CATEGORIES.map(c => (
                      <button key={c.id} onClick={() => setCat(c.id)}
                        className={`chip ${cat === c.id ? 'chip-active' : ''}`}
                        style={{ height: 28, fontSize: 12 }}>
                        {c.emoji} {c.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            <div className="dt-card" style={{ padding: 24 }}>
              <h3 className="dt-h2" style={{ marginBottom: 16 }}>3 · Voice & visibility</h3>
              <DTFormRow label="Voice" value="Warm · en-US"/>
              <DTFormRow label="Speech rate" value="1.0×" range/>
              <DTFormRow label="Visibility" value="🔗 Public — anyone with the link" last/>
            </div>

            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8 }}>
              <button className="dt-btn dt-btn-secondary">Save as draft</button>
              <button className="dt-btn dt-btn-primary dt-btn-lg" onClick={() => setStage('processing')}>
                <Ico.spark/> Process with Claude
              </button>
            </div>
          </div>

          {/* Right: tips */}
          <aside>
            <div className="dt-card" style={{ padding: 18, marginBottom: 16,
              background: 'linear-gradient(135deg, var(--accent-soft) 0%, var(--surface) 100%)' }}>
              <div className="dt-eyebrow" style={{ color: 'var(--accent-ink)' }}>HOW IT WORKS</div>
              <div style={{ fontSize: 14, fontWeight: 600, marginTop: 6 }}>Claude reads your guide once.</div>
              <div style={{ fontSize: 12.5, color: 'var(--ink-2)', marginTop: 6, lineHeight: 1.5 }}>
                Then it can answer questions, surface the right diagram, and check your work — for every reader, forever.
              </div>
            </div>
            <div className="dt-card" style={{ padding: 18 }}>
              <h3 className="dt-h2" style={{ fontSize: 14, marginBottom: 10 }}>What works best</h3>
              <ul style={{ margin: 0, padding: '0 0 0 16px', fontSize: 12.5, color: 'var(--muted)', lineHeight: 1.7 }}>
                <li>Numbered or clearly sequenced steps</li>
                <li>Embedded diagrams or photos per step</li>
                <li>Concise prose, not flowing essay</li>
                <li>10–50 pages (longer also works)</li>
              </ul>
            </div>
          </aside>
        </div>
      )}

      {stage === 'processing' && (
        <div style={{ textAlign: 'center', padding: '80px 32px' }}>
          <div style={{ position: 'relative', width: 120, height: 120, margin: '0 auto 28px' }}>
            <div style={{ position: 'absolute', inset: 0, borderRadius: '50%',
              background: 'var(--accent-soft)', animation: 'pulseRing 1.6s infinite' }}/>
            <div style={{
              position: 'absolute', inset: 14, borderRadius: '50%',
              background: 'var(--accent)', color: '#fff',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}>
              <Ico.spark style={{width: 40, height: 40}}/>
            </div>
          </div>
          <h2 style={{ fontSize: 28, fontWeight: 600, letterSpacing: '-0.02em', margin: '0 0 6px' }}>
            Junior is reading your guide
          </h2>
          <p style={{ fontSize: 14, color: 'var(--muted)' }}>This usually takes 20–60 seconds.</p>
        </div>
      )}

      {stage === 'done' && (
        <div style={{ textAlign: 'center', padding: '60px 32px', maxWidth: 560, margin: '0 auto' }}>
          <div style={{
            width: 80, height: 80, borderRadius: 99, margin: '0 auto 20px',
            background: 'var(--accent)', color: '#fff',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>
            <Ico.check style={{width:40, height:40}}/>
          </div>
          <h2 style={{ fontSize: 28, fontWeight: 600, letterSpacing: '-0.02em', margin: '0 0 8px' }}>
            Guide ready
          </h2>
          <p style={{ fontSize: 14, color: 'var(--muted)', marginBottom: 24 }}>
            9 steps extracted. AI crop boxes on every page.
          </p>
          <div className="dt-card" style={{ padding: 18, marginBottom: 20, textAlign: 'left' }}>
            <div className="dt-eyebrow">SHARE LINK</div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginTop: 8 }}>
              <Ico.link style={{ color: 'var(--accent)' }}/>
              <span style={{ flex: 1, fontFamily: 'var(--font-mono)', fontSize: 14 }}>junior.app/g/abc123</span>
              <button className="dt-btn dt-btn-secondary">Copy</button>
            </div>
          </div>
          <div style={{ display: 'flex', gap: 10, justifyContent: 'center' }}>
            <button className="dt-btn dt-btn-secondary dt-btn-lg" onClick={onBack}>View guide</button>
            <button className="dt-btn dt-btn-primary dt-btn-lg" onClick={onCreated}>
              <Ico.mic style={{width:16,height:16}}/> Start session
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

Object.assign(window, { DTGuideDetail, DTProfile, DTCreate });

function GuideStepRow({ step }) {
  return (
    <div className="dt-card" style={{ padding: 14, display: 'flex', gap: 14, alignItems: 'flex-start' }}>
      <div style={{
        width: 32, height: 32, borderRadius: 8,
        background: 'var(--surface-2)', border: '1px solid var(--border)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontSize: 12, fontWeight: 600, flexShrink: 0,
      }} className="mono stepnum">{String(step.i).padStart(2,'0')}</div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: 14, fontWeight: 600, letterSpacing: '-0.005em' }}>{step.title}</div>
        <div style={{ fontSize: 12.5, color: 'var(--muted)', marginTop: 3, lineHeight: 1.5 }}>{step.body}</div>
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, color: 'var(--muted-2)' }}>
        <span className="mono" style={{ fontSize: 10.5 }}>~45s</span>
        <button className="dt-iconbtn" style={{ width: 26, height: 26 }}><Ico.play style={{width:12,height:12}}/></button>
      </div>
    </div>
  );
}

window.GuideStepRow = GuideStepRow;
