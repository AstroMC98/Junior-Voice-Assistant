// Profile + Team screens

function ScreenProfile({ onLogout, onTheme, themeDark }) {
  return (
    <div className="app-scroll">
      <ScreenHeader
        title="Profile"
        sub="Account, voice, and library settings"
        right={
          <button style={{
            width: 40, height: 40, borderRadius: 99,
            background: 'var(--surface-2)', border: '1px solid var(--border)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}><Ico.setting /></button>
        }
      />

      {/* Identity card */}
      <div style={{ padding: '0 20px 16px' }}>
        <div className="card card-pad" style={{ padding: 18, display: 'flex', gap: 14, alignItems: 'center' }}>
          <Avatar size={56} initials={ME.initials} color={ME.avatar}/>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontSize: 17, fontWeight: 600, letterSpacing: '-0.01em' }}>{ME.name}</div>
            <div style={{ fontSize: 12, color: 'var(--muted)' }}>{ME.email}</div>
            <div style={{ display: 'flex', gap: 6, marginTop: 6 }}>
              <span className="tag tag-accent">{ME.plan.toUpperCase()}</span>
              <span className="tag">Member since {ME.joined}</span>
            </div>
          </div>
        </div>
      </div>

      {/* stats */}
      <div style={{ padding: '0 20px 20px', display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 8 }}>
        {[
          { l: 'Guides',    v: ME.guides },
          { l: 'Forks',     v: ME.forks },
          { l: 'Followers', v: ME.followers },
        ].map((s, i) => (
          <div key={i} className="card card-pad" style={{ padding: 12, textAlign: 'center' }}>
            <div style={{ fontSize: 22, fontWeight: 600, letterSpacing: '-0.02em' }}>{s.v}</div>
            <div style={{ fontSize: 10, color: 'var(--muted)', textTransform: 'uppercase', letterSpacing: 0.04, marginTop: 2 }} className="mono">{s.l}</div>
          </div>
        ))}
      </div>

      {/* settings groups */}
      <SectionTitle>Voice</SectionTitle>
      <SettingsGroup>
        <SettingsRow label="Junior's voice"    value="Warm · en-US" icon="🎙"/>
        <SettingsRow label="Speech rate"       value="1.0×"/>
        <SettingsRow label="Wake word"         value='"Hey Junior"'/>
        <SettingsRow label="Background noise" value="Auto-suppress" last/>
      </SettingsGroup>

      <SectionTitle>Appearance</SectionTitle>
      <SettingsGroup>
        <div style={{
          padding: '14px 16px', display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          borderBottom: '1px solid var(--border)',
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <span style={{ fontSize: 16 }}>🎨</span>
            <span style={{ fontSize: 14 }}>Theme</span>
          </div>
          <div className="seg">
            <button className={!themeDark ? 'on' : ''} onClick={() => onTheme(false)}>
              <Ico.sun style={{width:14,height:14, marginRight: 4}}/> Light
            </button>
            <button className={themeDark ? 'on' : ''} onClick={() => onTheme(true)}>
              <Ico.moon style={{width:14,height:14, marginRight: 4}}/> Dark
            </button>
          </div>
        </div>
        <SettingsRow label="Accent color"  value="Amber"/>
        <SettingsRow label="Text size"     value="Medium" last/>
      </SettingsGroup>

      <SectionTitle>Library & sharing</SectionTitle>
      <SettingsGroup>
        <SettingsRow label="Default visibility" value="🔗 Public"/>
        <SettingsRow label="Auto-fork on edit"  value="On"/>
        <SettingsRow label="Storage used"       value="142 MB / 5 GB" last/>
      </SettingsGroup>

      <SectionTitle>Account</SectionTitle>
      <SettingsGroup>
        <SettingsRow label="Plan"          value="Pro · $5/mo"/>
        <SettingsRow label="Billing"       value="Manage"/>
        <SettingsRow label="Data & export" value=""/>
        <SettingsRow label="Sign out"      value="" danger onClick={onLogout} last/>
      </SettingsGroup>

      <div style={{ padding: '24px 20px', textAlign: 'center', fontSize: 11, color: 'var(--muted-2)' }} className="mono">
        JUNIOR v1.2.4 · BUILD 2026.05.14
      </div>
    </div>
  );
}

function SectionTitle({ children }) {
  return (
    <div style={{
      padding: '4px 24px 8px', fontSize: 11, color: 'var(--muted)',
      textTransform: 'uppercase', letterSpacing: 0.06,
    }} className="mono">{children}</div>
  );
}

function SettingsGroup({ children }) {
  return (
    <div style={{ padding: '0 20px 16px' }}>
      <div className="card" style={{ overflow: 'hidden' }}>{children}</div>
    </div>
  );
}

function SettingsRow({ label, value, last, danger, icon, onClick }) {
  return (
    <button onClick={onClick} style={{
      width: '100%', padding: '14px 16px',
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      borderBottom: last ? 0 : '1px solid var(--border)',
      textAlign: 'left',
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
        {icon && <span style={{ fontSize: 16 }}>{icon}</span>}
        <span style={{ fontSize: 14, color: danger ? '#DC2626' : 'var(--ink)' }}>{label}</span>
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 13, color: 'var(--muted)' }}>
        {value}
        <Ico.chev style={{ color: 'var(--muted-2)' }}/>
      </div>
    </button>
  );
}

// ─── Team ───────────────────────────────────────────────────
function ScreenTeam() {
  const [tab, setTab] = React.useState('members');

  return (
    <div className="app-scroll">
      <ScreenHeader
        title="Team"
        sub="Junior Cooking Co · 5 members"
        right={
          <button className="btn btn-sm" style={{ background: 'var(--accent)', color: '#fff' }}>
            <Ico.plus style={{width:14, height:14}}/> Invite
          </button>
        }
      />

      {/* team summary */}
      <div style={{ padding: '0 20px 16px' }}>
        <div className="card card-pad" style={{ padding: 18, position: 'relative', overflow: 'hidden' }}>
          <div style={{
            position: 'absolute', top: 0, right: 0, width: 140, height: 140,
            background: 'radial-gradient(circle, var(--accent-soft) 0%, transparent 70%)',
          }}/>
          <div style={{ position: 'relative' }}>
            <div style={{ fontSize: 11, color: 'var(--muted)', textTransform: 'uppercase', letterSpacing: 0.06 }} className="mono">
              ACTIVE WORKSPACE
            </div>
            <div style={{ fontSize: 22, fontWeight: 600, letterSpacing: '-0.02em', marginTop: 4 }}>
              Junior Cooking Co.
            </div>
            <div style={{ fontSize: 13, color: 'var(--muted)', marginTop: 4 }}>
              Recipes & manuals, shared across 5 members.
            </div>

            {/* avatar stack */}
            <div style={{ display: 'flex', marginTop: 14, gap: -8 }}>
              {TEAM.slice(0, 5).map((m, i) => (
                <div key={m.id} style={{ marginLeft: i === 0 ? 0 : -10 }}>
                  <Avatar size={36} initials={m.initials} color={m.avatar} ring/>
                </div>
              ))}
            </div>

            <div style={{ display: 'flex', gap: 8, marginTop: 14 }}>
              <button className="btn btn-secondary btn-sm">
                <Ico.share/> Invite link
              </button>
              <button className="btn btn-secondary btn-sm">
                <Ico.setting style={{width:14, height:14}}/> Settings
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* tabs */}
      <div style={{ padding: '0 20px 14px' }}>
        <div className="seg" style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)' }}>
          {[
            { id: 'members',  l: 'Members',  n: 5 },
            { id: 'shared',   l: 'Shared',   n: 12 },
            { id: 'activity', l: 'Activity', n: 8 },
          ].map(t => (
            <button key={t.id} className={tab === t.id ? 'on' : ''} onClick={() => setTab(t.id)}>
              {t.l} <span style={{ color: 'var(--muted-2)', fontWeight: 500 }}>{t.n}</span>
            </button>
          ))}
        </div>
      </div>

      {tab === 'members' && (
        <div style={{ padding: '0 20px 24px', display: 'flex', flexDirection: 'column', gap: 6 }}>
          {TEAM.map(m => (
            <div key={m.id} style={{
              padding: 12, background: 'var(--surface)', border: '1px solid var(--border)',
              borderRadius: 14, display: 'flex', alignItems: 'center', gap: 12,
            }}>
              <div style={{ position: 'relative' }}>
                <Avatar size={42} initials={m.initials} color={m.avatar}/>
                {m.online && (
                  <div style={{
                    position: 'absolute', bottom: 0, right: 0,
                    width: 12, height: 12, borderRadius: 99,
                    background: '#22C55E', border: '2px solid var(--surface)',
                  }}/>
                )}
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 14, fontWeight: 600, letterSpacing: '-0.005em' }}>{m.name}</div>
                <div style={{ fontSize: 12, color: 'var(--muted)', display: 'flex', gap: 6, alignItems: 'center' }}>
                  <span>{m.role}</span>
                  {m.online && <><span>·</span><span style={{ color: '#22C55E' }}>Active now</span></>}
                </div>
              </div>
              <button style={{ padding: 6, color: 'var(--muted-2)' }}><Ico.more/></button>
            </div>
          ))}

          <button className="btn btn-secondary btn-block" style={{
            marginTop: 8, height: 48, borderStyle: 'dashed',
            color: 'var(--muted)',
          }}>
            <Ico.plus style={{width: 16, height: 16}}/> Invite member
          </button>
        </div>
      )}

      {tab === 'shared' && (
        <div style={{ padding: '0 20px 24px', display: 'flex', flexDirection: 'column', gap: 10 }}>
          {GUIDES.slice(0, 5).map(g => (
            <SharedGuideRow key={g.id} guide={g}/>
          ))}
        </div>
      )}

      {tab === 'activity' && (
        <div style={{ padding: '0 20px 24px', display: 'flex', flexDirection: 'column', gap: 14 }}>
          {ACTIVITY.map((a, i) => (
            <div key={i} style={{ display: 'flex', gap: 12, alignItems: 'flex-start' }}>
              <Avatar size={36} initials={a.initials} color={a.avatar}/>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 13.5, lineHeight: 1.4 }}>
                  <span style={{ fontWeight: 600 }}>{a.who}</span>
                  <span style={{ color: 'var(--muted)' }}> {a.text}</span>
                </div>
                <div style={{ fontSize: 11, color: 'var(--muted-2)', marginTop: 2 }} className="mono">
                  {a.ago.toUpperCase()} AGO
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function SharedGuideRow({ guide }) {
  return (
    <div style={{
      padding: 12, background: 'var(--surface)', border: '1px solid var(--border)',
      borderRadius: 14, display: 'flex', alignItems: 'center', gap: 12,
    }}>
      <div style={{
        width: 44, height: 44, borderRadius: 10, background: guide.bg,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontSize: 22, flexShrink: 0,
      }}>{guide.glyph}</div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: 13.5, fontWeight: 600, letterSpacing: '-0.005em' }}>{guide.title}</div>
        <div style={{ fontSize: 12, color: 'var(--muted)', marginTop: 2 }}>
          {guide.author.name} · {guide.stepsCount} steps
        </div>
      </div>
      <div style={{ display: 'flex', marginRight: 8 }}>
        {TEAM.slice(0, 3).map((m, i) => (
          <div key={m.id} style={{ marginLeft: i === 0 ? 0 : -8 }}>
            <Avatar size={20} initials={m.initials} color={m.avatar} ring/>
          </div>
        ))}
      </div>
      <Ico.more style={{ color: 'var(--muted-2)', flexShrink: 0 }}/>
    </div>
  );
}

Object.assign(window, { ScreenProfile, ScreenTeam });
