// Main app — routing, frame, tweaks

const DEFAULTS = /*EDITMODE-BEGIN*/{
  "theme": "light",
  "accent": "amber",
  "sessionVariant": "classic",
  "waveStyle": "bars",
  "showFrame": true,
  "startScreen": "discover"
}/*EDITMODE-END*/;

function App() {
  const [t, setTweak] = useTweaks(DEFAULTS);

  // navigation
  const [screen, setScreen] = React.useState(t.startScreen || 'discover');
  const [guide, setGuide] = React.useState(GUIDES[0]);
  const [tab, setTab] = React.useState('discover');
  const [authed, setAuthed] = React.useState(true); // start signed in for convenience

  // session is a fullscreen modal layer over the tab structure
  const [sessionOpen, setSessionOpen] = React.useState(false);
  const [createOpen, setCreateOpen] = React.useState(false);

  // tab change
  const onTab = (id) => {
    if (id === 'create') { setCreateOpen(true); return; }
    setTab(id);
    setScreen(id);
  };

  const openGuide = (g) => {
    setGuide(g);
    setScreen('guide');
  };

  const startSession = () => {
    setSessionOpen(true);
  };

  // dark mode toggle helper
  const isDark = t.theme === 'dark';
  const themeClass = `theme-${t.theme} accent-${t.accent}`;

  // ── Render ─────────────────────────────────────────────────
  const inner = (
    <div className={`app ${themeClass}`}>
      {/* main content */}
      <div style={{ flex: 1, overflow: 'hidden', position: 'relative', display: 'flex', flexDirection: 'column' }}>
        {!authed && screen === 'landing' && (
          <ScreenLanding
            onContinue={() => { setAuthed(true); setScreen('discover'); setTab('discover'); }}
            onLogin={() => setScreen('login')}
          />
        )}
        {!authed && screen === 'login' && (
          <ScreenLogin
            onSuccess={() => { setAuthed(true); setScreen('discover'); setTab('discover'); }}
            onBack={() => setScreen('landing')}
          />
        )}

        {authed && screen === 'discover' && (
          <ScreenDiscover onOpenGuide={openGuide} />
        )}
        {authed && screen === 'library' && (
          <ScreenLibrary onOpenGuide={openGuide} onCreate={() => setCreateOpen(true)} />
        )}
        {authed && screen === 'team' && (
          <ScreenTeam />
        )}
        {authed && screen === 'profile' && (
          <ScreenProfile
            onLogout={() => { setAuthed(false); setScreen('landing'); }}
            onTheme={(d) => setTweak('theme', d ? 'dark' : 'light')}
            themeDark={isDark}
          />
        )}
        {authed && screen === 'guide' && (
          <ScreenGuideDetail
            guide={guide}
            onBack={() => setScreen(tab)}
            onStart={startSession}
            onFork={() => alert('Forked!')}
          />
        )}
      </div>

      {/* Tab bar (hidden on guide detail + auth) */}
      {authed && ['discover', 'library', 'team', 'profile'].includes(screen) && (
        <TabBar active={tab} onChange={onTab} />
      )}

      {/* Session — fullscreen modal */}
      {sessionOpen && (
        <div style={{
          position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, zIndex: 200,
        }}>
          <ScreenSession
            guide={guide}
            onClose={() => setSessionOpen(false)}
            variant={t.sessionVariant}
            waveStyle={t.waveStyle}
          />
        </div>
      )}

      {/* Create — fullscreen modal */}
      {createOpen && (
        <div style={{
          position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, zIndex: 150, background: 'var(--bg)',
        }}>
          <ScreenCreate
            onBack={() => setCreateOpen(false)}
            onCreated={() => { setCreateOpen(false); openGuide(GUIDES[0]); }}
          />
        </div>
      )}
    </div>
  );

  // Status bar overlay on top
  const withStatus = (
    <>
      <StatusBar dark={isDark} />
      {inner}
    </>
  );

  return (
    <div className={themeClass} style={{
      minHeight: '100vh', width: '100%',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      padding: t.showFrame ? '24px 0' : 0,
      background: t.showFrame
        ? (isDark
          ? 'radial-gradient(ellipse at top, #2a2620 0%, #0a0908 60%)'
          : 'radial-gradient(ellipse at top, #e5e1d4 0%, #b8b1a0 60%)')
        : 'var(--bg)',
    }}>
      {t.showFrame ? (
        <div style={{
          width: 402, height: 874, borderRadius: 56, overflow: 'hidden',
          position: 'relative', boxShadow: '0 50px 100px rgba(0,0,0,0.35), 0 0 0 12px #18171a, 0 0 0 13px rgba(0,0,0,0.4)',
        }}>
          {/* dynamic island */}
          <div style={{
            position: 'absolute', top: 11, left: '50%', transform: 'translateX(-50%)',
            width: 126, height: 37, borderRadius: 24, background: '#000', zIndex: 100,
          }}/>
          {/* home indicator */}
          <div style={{
            position: 'absolute', bottom: 8, left: 0, right: 0,
            display: 'flex', justifyContent: 'center', zIndex: 100, pointerEvents: 'none',
          }}>
            <div style={{
              width: 139, height: 5, borderRadius: 99,
              background: isDark ? 'rgba(255,255,255,0.7)' : 'rgba(0,0,0,0.4)',
            }}/>
          </div>
          {withStatus}
        </div>
      ) : (
        <div style={{
          width: '100%', maxWidth: 480, height: '100vh',
          margin: '0 auto', position: 'relative',
        }}>
          {withStatus}
        </div>
      )}

      {/* Tweaks panel */}
      <TweaksPanel title="Tweaks" noDeckControls>
        <TweakSection label="Theme">
          <TweakRadio label="Mode" value={t.theme}
            options={[{value:'light',label:'Light'},{value:'dark',label:'Dark'}]}
            onChange={(v) => setTweak('theme', v)} />
          <TweakColor label="Accent" value={t.accent}
            options={[
              { value: 'amber', color: '#F26B3A' },
              { value: 'mint',  color: '#2DBE7A' },
              { value: 'iris',  color: '#5B6CFF' },
            ]}
            onChange={(v) => setTweak('accent', v)} />
        </TweakSection>

        <TweakSection label="Voice session">
          <TweakRadio label="Layout" value={t.sessionVariant}
            options={[
              {value:'classic', label:'Classic'},
              {value:'visual',  label:'Visual'},
              {value:'coach',   label:'Coach'},
            ]}
            onChange={(v) => setTweak('sessionVariant', v)} />
          <TweakRadio label="Waveform" value={t.waveStyle}
            options={[
              {value:'bars', label:'Bars'},
              {value:'line', label:'Line'},
              {value:'ring', label:'Ring'},
            ]}
            onChange={(v) => setTweak('waveStyle', v)} />
          <TweakButton label="Open KTANE session" onClick={() => {
            setGuide(GUIDES[0]);
            setSessionOpen(true);
          }}/>
        </TweakSection>

        <TweakSection label="Frame">
          <TweakToggle label="Show iPhone frame" value={t.showFrame}
            onChange={(v) => setTweak('showFrame', v)}/>
        </TweakSection>

        <TweakSection label="Jump to screen">
          <TweakSelect label="Screen" value={screen}
            options={[
              { value: 'discover', label: 'Discover' },
              { value: 'library',  label: 'Library' },
              { value: 'team',     label: 'Team' },
              { value: 'profile',  label: 'Profile' },
              { value: 'guide',    label: 'Guide detail' },
              { value: 'landing',  label: 'Landing' },
              { value: 'login',    label: 'Login' },
            ]}
            onChange={(v) => {
              setScreen(v);
              if (['discover','library','team','profile'].includes(v)) {
                setTab(v); setAuthed(true);
              }
              if (v === 'landing' || v === 'login') setAuthed(false);
            }}/>
        </TweakSection>
      </TweaksPanel>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App/>);
