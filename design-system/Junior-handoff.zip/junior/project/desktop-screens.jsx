// Desktop screens — Junior

// ─── Sidebar ────────────────────────────────────────────────
function DTSidebar({ active, onNav, screen, onOpenGuide }) {
  const navItems = [
    { id: 'discover', label: 'Discover', icon: Ico.home,    badge: null },
    { id: 'library',  label: 'Library',  icon: Ico.library, badge: '8' },
    { id: 'team',     label: 'Team',     icon: Ico.team,    badge: '5' },
    { id: 'profile',  label: 'Profile',  icon: Ico.user,    badge: null },
  ];

  return (
    <aside className="dt-side">
      <div className="dt-logo">
        <div className="dt-logo-mark">J</div>
        <div>
          <div className="dt-logo-name">Junior</div>
          <div className="dt-logo-sub">v1.2.4</div>
        </div>
      </div>

      <button className="dt-btn dt-btn-primary" onClick={() => onNav('create')}
        style={{ width: '100%', marginBottom: 10 }}>
        <Ico.plus style={{width:16,height:16}}/> New guide
      </button>

      <div className="dt-side-label">Workspace</div>
      {navItems.map(item => (
        <button key={item.id}
          className={`dt-nav-item ${active === item.id ? 'active' : ''}`}
          onClick={() => onNav(item.id)}>
          <span className="nav-ico"><item.icon /></span>
          <span>{item.label}</span>
          {item.badge && <span className="nav-badge">{item.badge}</span>}
        </button>
      ))}

      <div className="dt-side-label">Categories</div>
      {CATEGORIES.slice(0,5).map(c => (
        <button key={c.id} className="dt-nav-item" onClick={() => onNav('discover', c.id)}>
          <span className="nav-ico" style={{fontSize:14, display:'flex', alignItems:'center', justifyContent:'center'}}>{c.emoji}</span>
          <span>{c.label}</span>
          <span className="nav-badge">{c.count}</span>
        </button>
      ))}

      <div style={{ flex: 1 }}/>

      {/* Recent runs */}
      <div className="dt-side-label">Recent</div>
      {GUIDES.slice(0, 2).map(g => (
        <button key={g.id} className="dt-nav-item" onClick={() => onOpenGuide(g)} style={{ padding: '8px 8px' }}>
          <div style={{
            width: 24, height: 24, borderRadius: 6, background: g.bg,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: 14, flexShrink: 0,
          }}>{g.glyph}</div>
          <span style={{ fontSize: 12.5, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{g.title}</span>
        </button>
      ))}

      {/* User card */}
      <div style={{
        marginTop: 14, padding: 10, borderRadius: 10,
        background: 'var(--surface)', border: '1px solid var(--border)',
        display: 'flex', gap: 10, alignItems: 'center',
      }}>
        <Avatar size={32} initials={ME.initials} color={ME.avatar}/>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 12.5, fontWeight: 600, whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis' }}>{ME.name}</div>
          <div style={{ fontSize: 10.5, color: 'var(--muted)' }} className="mono">PRO · {ME.email}</div>
        </div>
        <button className="dt-iconbtn" style={{ width: 28, height: 28 }}>
          <Ico.setting style={{width:16,height:16}}/>
        </button>
      </div>
    </aside>
  );
}

// ─── Top bar ───────────────────────────────────────────────
function DTTopBar({ title, search, onSearch, themeDark, onTheme, accent, onAccent, onJump }) {
  return (
    <header className="dt-top">
      <div style={{ fontSize: 13.5, color: 'var(--muted)', display: 'flex', alignItems: 'center', gap: 6 }}>
        <span style={{ color: 'var(--ink-2)', fontWeight: 500 }}>{title}</span>
      </div>
      <div style={{ flex: 1 }}/>
      <div className="dt-search">
        <Ico.search style={{ color: 'var(--muted)' }}/>
        <input placeholder="Search guides, steps, people…" value={search} onChange={e => onSearch(e.target.value)}/>
        <span className="kbd">⌘K</span>
      </div>
      <div style={{ display: 'flex', gap: 4 }}>
        <button className="dt-iconbtn" onClick={() => onTheme(!themeDark)} title="Toggle theme">
          {themeDark ? <Ico.sun/> : <Ico.moon/>}
        </button>
        <button className="dt-iconbtn" title="Notifications">
          <Ico.bell/>
          <span style={{
            position: 'absolute', top: 8, right: 8,
            width: 6, height: 6, borderRadius: 99, background: 'var(--accent)',
          }}/>
        </button>
        <button className="dt-iconbtn" onClick={onJump} title="Help">
          <span style={{fontSize: 14, fontWeight: 700}}>?</span>
        </button>
      </div>
    </header>
  );
}

// ─── Discover ────────────────────────────────────────────────
function DTDiscover({ onOpenGuide, search, filterCategory, onFilterCategory }) {
  const featured = GUIDES.find(g => g.featured) || GUIDES[0];

  const matches = (g) =>
    (filterCategory === 'all' || g.category === filterCategory) &&
    (search === '' || g.title.toLowerCase().includes(search.toLowerCase()));

  const filtered = GUIDES.filter(matches);

  // group by category for rails (when on 'all' and no search)
  const byCat = {};
  CATEGORIES.forEach(c => { byCat[c.id] = GUIDES.filter(g => g.category === c.id); });

  const showRails = filterCategory === 'all' && search === '';

  return (
    <div className="dt-main-pad">
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 320px', gap: 28 }}>
        {/* Main column */}
        <div>
          {/* Eyebrow + title */}
          <div className="dt-eyebrow" style={{ marginBottom: 6 }}>WHAT TO MAKE TODAY</div>
          <h1 className="dt-h1">
            Hi Sam — pick up where you left off
          </h1>
          <div style={{ color: 'var(--muted)', fontSize: 14, marginTop: 4 }}>
            Last session: <strong style={{color:'var(--ink-2)'}}>KTANE — Bomb Manual, Wires module in progress</strong> · 18 minutes ago
          </div>

          {/* Resume card */}
          <button onClick={() => onOpenGuide(GUIDES[0])} className="dt-card" style={{
            display: 'flex', gap: 16, padding: 18, marginTop: 18,
            width: '100%', textAlign: 'left', alignItems: 'center',
          }}>
            <div style={{
              width: 72, height: 72, borderRadius: 12, background: GUIDES[0].bg,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontSize: 34, flexShrink: 0,
            }}>{GUIDES[0].glyph}</div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div className="dt-eyebrow">RESUME SESSION</div>
              <div style={{ fontSize: 17, fontWeight: 600, letterSpacing: '-0.015em', marginTop: 2 }}>
                {GUIDES[0].title}
              </div>
              <div style={{ fontSize: 12.5, color: 'var(--muted)', marginTop: 4 }}>
                Wires module · sub-step 6 of 7 · "6 wires"
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 8 }}>
                <div style={{ flex: 1, maxWidth: 200, height: 4, borderRadius: 99, background: 'var(--surface-3)' }}>
                  <div style={{ width: '33%', height: '100%', background: 'var(--accent)', borderRadius: 99 }}/>
                </div>
                <span className="mono" style={{ fontSize: 10.5, color: 'var(--muted)' }}>33%</span>
              </div>
            </div>
            <div className="dt-btn dt-btn-primary">
              <Ico.mic style={{width:14,height:14}}/> Continue
            </div>
          </button>

          {/* Category chips */}
          <div style={{ display: 'flex', gap: 6, marginTop: 28, flexWrap: 'wrap' }}>
            <button onClick={() => onFilterCategory('all')}
              className={`chip ${filterCategory === 'all' ? 'chip-active' : ''}`}
              style={{ height: 32, fontSize: 12.5 }}>
              ✨ All <span style={{opacity:0.6,marginLeft:4}}>{GUIDES.length}</span>
            </button>
            {CATEGORIES.map(c => (
              <button key={c.id} onClick={() => onFilterCategory(c.id)}
                className={`chip ${filterCategory === c.id ? 'chip-active' : ''}`}
                style={{ height: 32, fontSize: 12.5 }}>
                {c.emoji} {c.label} <span style={{opacity:0.6,marginLeft:4}}>{c.count}</span>
              </button>
            ))}
          </div>

          {showRails ? (
            <>
              {CATEGORIES.slice(0,4).map(c => byCat[c.id]?.length > 0 && (
                <section key={c.id} style={{ marginTop: 32 }}>
                  <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: 14 }}>
                    <h2 className="dt-h2">
                      <span style={{ marginRight: 8 }}>{c.emoji}</span>{c.label}
                      <span style={{ color: 'var(--muted-2)', fontWeight: 500, marginLeft: 8, fontSize: 13 }}>· {c.count} guides</span>
                    </h2>
                    <button className="dt-btn dt-btn-ghost" style={{ height: 30, fontSize: 12.5 }}>
                      See all <Ico.chev style={{width:14,height:14}}/>
                    </button>
                  </div>
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16 }}>
                    {byCat[c.id].slice(0,4).map(g => <DTGuideCard key={g.id} guide={g} onClick={() => onOpenGuide(g)} />)}
                  </div>
                </section>
              ))}
            </>
          ) : (
            <section style={{ marginTop: 24 }}>
              <h2 className="dt-h2" style={{ marginBottom: 14 }}>
                {search ? `${filtered.length} results for "${search}"` : CATEGORIES.find(c => c.id === filterCategory)?.label}
              </h2>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16 }}>
                {filtered.map(g => <DTGuideCard key={g.id} guide={g} onClick={() => onOpenGuide(g)}/>)}
              </div>
            </section>
          )}
        </div>

        {/* Right column — activity + tips */}
        <aside>
          <div className="dt-card" style={{ padding: 18, marginBottom: 16 }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
              <h3 className="dt-h2" style={{ fontSize: 15 }}>Activity</h3>
              <button className="dt-btn dt-btn-ghost" style={{ height: 26, padding: '0 8px', fontSize: 12 }}>All</button>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
              {ACTIVITY.map((a, i) => (
                <div key={i} style={{ display: 'flex', gap: 10, alignItems: 'flex-start' }}>
                  <Avatar size={28} initials={a.initials} color={a.avatar}/>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontSize: 12.5, lineHeight: 1.4 }}>
                      <strong style={{ fontWeight: 600 }}>{a.who}</strong>
                      <span style={{ color: 'var(--muted)' }}> {a.text}</span>
                    </div>
                    <div style={{ fontSize: 10.5, color: 'var(--muted-2)', marginTop: 2 }} className="mono">{a.ago.toUpperCase()} AGO</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="dt-card" style={{ padding: 18, marginBottom: 16, background: 'linear-gradient(135deg, var(--accent-soft) 0%, var(--surface) 100%)' }}>
            <div className="dt-eyebrow" style={{ color: 'var(--accent-ink)' }}>TIP OF THE DAY</div>
            <div style={{ fontSize: 15, fontWeight: 600, marginTop: 6, color: 'var(--accent-ink)' }}>
              "Hey Junior, what do I expect to see?"
            </div>
            <div style={{ fontSize: 12.5, color: 'var(--accent-ink)', marginTop: 6, opacity: 0.85 }}>
              Ask any time to surface the right diagram from your guide — even mid-session.
            </div>
          </div>

          <div className="dt-card" style={{ padding: 18 }}>
            <h3 className="dt-h2" style={{ fontSize: 15, marginBottom: 12 }}>Top creators</h3>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              {TEAM.slice(0,4).map(m => (
                <div key={m.id} style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
                  <Avatar size={32} initials={m.initials} color={m.avatar}/>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontSize: 13, fontWeight: 600 }}>{m.name}</div>
                    <div style={{ fontSize: 11, color: 'var(--muted)' }}>{Math.floor(20 + Math.random()*200)} runs</div>
                  </div>
                  <button className="dt-btn dt-btn-secondary" style={{ height: 26, padding: '0 10px', fontSize: 11.5 }}>Follow</button>
                </div>
              ))}
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
}

function DTGuideCard({ guide, onClick }) {
  return (
    <button className="dt-gcard" onClick={onClick}>
      <div className="dt-gcard-bg" style={{ background: guide.bg }}>
        <div style={{ position: 'absolute', top: 12, left: 14, fontSize: 30, zIndex: 1,
          filter: 'drop-shadow(0 2px 6px rgba(0,0,0,0.3))' }}>{guide.glyph}</div>
        <div style={{ position: 'absolute', top: 12, right: 12, zIndex: 2,
          display: 'flex', gap: 4, alignItems: 'center',
          background: 'rgba(0,0,0,0.3)', backdropFilter: 'blur(8px)',
          padding: '4px 8px', borderRadius: 99,
          color: '#fff', fontSize: 11, fontWeight: 500,
        }}>
          <Ico.star style={{width:11,height:11}}/> {guide.rating}
        </div>
        <div style={{ position: 'absolute', bottom: 12, left: 14, right: 14, zIndex: 2, color: '#fff' }}>
          <div style={{ fontSize: 10.5, opacity: 0.85, marginBottom: 2 }} className="mono">
            {guide.stepsCount} STEPS · {guide.duration}
          </div>
        </div>
      </div>
      <div className="dt-gcard-meta">
        <div className="dt-gcard-title">{guide.title}</div>
        <div className="dt-gcard-sub" style={{display:'flex',alignItems:'center',gap:6}}>
          <Avatar size={16} initials={guide.author.initials} color={guide.author.avatar}/> {guide.author.name}
        </div>
      </div>
    </button>
  );
}

// ─── Library ────────────────────────────────────────────────
function DTLibrary({ onOpenGuide }) {
  const [tab, setTab] = React.useState('mine');
  const tabs = [
    { id: 'mine', label: 'My guides', n: 8 },
    { id: 'forks', label: 'Forks', n: 14 },
    { id: 'saved', label: 'Saved', n: 23 },
    { id: 'drafts', label: 'Drafts', n: 2 },
  ];

  return (
    <div className="dt-main-pad">
      <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', marginBottom: 24 }}>
        <div>
          <div className="dt-eyebrow">LIBRARY</div>
          <h1 className="dt-h1">My guides</h1>
          <div style={{ color: 'var(--muted)', fontSize: 14, marginTop: 4 }}>8 guides created, 14 forked, 23 saved.</div>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <button className="dt-btn dt-btn-secondary"><Ico.share/> Export</button>
          <button className="dt-btn dt-btn-primary"><Ico.plus style={{width:16,height:16}}/> New guide</button>
        </div>
      </div>

      {/* Stats */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12, marginBottom: 24 }}>
        {[
          { l: 'Total sessions', v: '247', d: 'this year' },
          { l: 'Avg. duration',  v: '12m 24s', d: 'per session' },
          { l: 'Active streak',  v: '6 days', d: '🔥 keep going' },
          { l: 'Forks received', v: '318',   d: '+24 this week' },
        ].map((s, i) => (
          <div key={i} className="dt-stat">
            <div className="dt-stat-l">{s.l}</div>
            <div className="dt-stat-v">{s.v}</div>
            <div className="dt-stat-d">{s.d}</div>
          </div>
        ))}
      </div>

      {/* Tabs */}
      <div style={{ display: 'flex', gap: 4, marginBottom: 16, borderBottom: '1px solid var(--border)' }}>
        {tabs.map(t => (
          <button key={t.id} onClick={() => setTab(t.id)} style={{
            padding: '10px 14px',
            fontSize: 13.5, fontWeight: 500,
            color: tab === t.id ? 'var(--ink)' : 'var(--muted)',
            borderBottom: '2px solid',
            borderColor: tab === t.id ? 'var(--accent)' : 'transparent',
            marginBottom: -1,
          }}>
            {t.label} <span className="mono" style={{ color: 'var(--muted-2)', marginLeft: 4 }}>{t.n}</span>
          </button>
        ))}
      </div>

      {/* Table */}
      <div className="dt-card" style={{ overflow: 'hidden' }}>
        <div style={{
          padding: '10px 18px', fontSize: 11, color: 'var(--muted)', textTransform: 'uppercase',
          letterSpacing: 0.08, display: 'grid',
          gridTemplateColumns: '2fr 0.7fr 1fr 0.6fr 0.6fr 0.5fr 32px',
          gap: 16, borderBottom: '1px solid var(--border)',
        }} className="mono">
          <div>Guide</div>
          <div>Category</div>
          <div>Last run</div>
          <div>Steps</div>
          <div>Runs</div>
          <div>Visibility</div>
          <div/>
        </div>
        {GUIDES.slice(0, 8).map((g, i) => (
          <div key={g.id} onClick={() => onOpenGuide(g)} style={{
            padding: '14px 18px',
            display: 'grid',
            gridTemplateColumns: '2fr 0.7fr 1fr 0.6fr 0.6fr 0.5fr 32px',
            gap: 16, alignItems: 'center',
            borderBottom: i < 7 ? '1px solid var(--border)' : 0,
            cursor: 'pointer',
          }}>
            <div style={{ display: 'flex', gap: 12, alignItems: 'center', minWidth: 0 }}>
              <div style={{ width: 36, height: 36, borderRadius: 8, background: g.bg,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontSize: 18, flexShrink: 0 }}>{g.glyph}</div>
              <div style={{ minWidth: 0 }}>
                <div style={{ fontSize: 13.5, fontWeight: 600, letterSpacing: '-0.005em' }}>{g.title}</div>
                <div style={{ fontSize: 11.5, color: 'var(--muted)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{g.subtitle}</div>
              </div>
            </div>
            <div><span className="tag">{g.category}</span></div>
            <div style={{ fontSize: 12, color: 'var(--muted)' }}>
              <span style={{display:'flex',alignItems:'center',gap:4}} className="mono">
                <Ico.clock/> {['2h', '1d', '3d', '1w', '2w', '1mo', '3mo', '6mo'][i]} ago
              </span>
            </div>
            <div style={{ fontSize: 13 }} className="mono stepnum">{g.stepsCount}</div>
            <div style={{ fontSize: 13 }} className="mono">{(g.runs/1000).toFixed(1)}k</div>
            <div><span className="tag tag-accent" style={{ padding: '2px 6px' }}>{i % 3 === 0 ? 'PRIVATE' : 'PUBLIC'}</span></div>
            <button className="dt-iconbtn" style={{ width: 28, height: 28 }} onClick={(e) => e.stopPropagation()}><Ico.more/></button>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Team ───────────────────────────────────────────────────
function DTTeam() {
  return (
    <div className="dt-main-pad">
      <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', marginBottom: 24 }}>
        <div>
          <div className="dt-eyebrow">TEAM</div>
          <h1 className="dt-h1">Junior Cooking Co.</h1>
          <div style={{ color: 'var(--muted)', fontSize: 14, marginTop: 4 }}>Recipes, manuals, and runbooks — shared across 5 members.</div>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <button className="dt-btn dt-btn-secondary"><Ico.share/> Invite link</button>
          <button className="dt-btn dt-btn-primary"><Ico.plus style={{width:16,height:16}}/> Invite member</button>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 320px', gap: 24 }}>
        {/* Left */}
        <div>
          {/* Stats */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12, marginBottom: 20 }}>
            {[
              { l: 'Members', v: '5', d: '3 active now' },
              { l: 'Shared guides', v: '12' },
              { l: 'This week', v: '47 sessions' },
              { l: 'Storage', v: '142 MB', d: 'of 5 GB' },
            ].map((s, i) => (
              <div key={i} className="dt-stat">
                <div className="dt-stat-l">{s.l}</div>
                <div className="dt-stat-v">{s.v}</div>
                {s.d && <div className="dt-stat-d">{s.d}</div>}
              </div>
            ))}
          </div>

          {/* Members table */}
          <div className="dt-card">
            <div style={{ padding: '14px 18px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', borderBottom: '1px solid var(--border)' }}>
              <h3 className="dt-h2" style={{ fontSize: 15 }}>Members <span style={{ color: 'var(--muted)', fontWeight: 500, marginLeft: 6 }}>5</span></h3>
              <input placeholder="Filter members…" style={{
                height: 28, padding: '0 10px', fontSize: 12,
                background: 'var(--surface-2)', border: '1px solid var(--border)',
                borderRadius: 8, outline: 'none', width: 180,
              }}/>
            </div>
            {TEAM.map((m, i) => (
              <div key={m.id} style={{
                padding: '14px 18px', display: 'flex', alignItems: 'center', gap: 14,
                borderBottom: i < TEAM.length - 1 ? '1px solid var(--border)' : 0,
              }}>
                <div style={{ position: 'relative' }}>
                  <Avatar size={36} initials={m.initials} color={m.avatar}/>
                  {m.online && (
                    <div style={{ position: 'absolute', bottom: 0, right: 0,
                      width: 11, height: 11, borderRadius: 99,
                      background: '#22C55E', border: '2px solid var(--surface)' }}/>
                  )}
                </div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 13.5, fontWeight: 600 }}>{m.name}</div>
                  <div style={{ fontSize: 12, color: 'var(--muted)' }}>
                    {m.online ? <span style={{ color: '#22C55E' }}>● Active now</span> : '○ Offline'} · {['Boston, MA', 'London, UK', 'Berlin, DE', 'Mumbai, IN', 'San Francisco, CA'][i]}
                  </div>
                </div>
                <span className="tag" style={{ background: m.role === 'Owner' ? 'var(--accent-soft)' : 'var(--surface-2)',
                  color: m.role === 'Owner' ? 'var(--accent-ink)' : 'var(--muted)' }}>{m.role.toUpperCase()}</span>
                <div style={{ display: 'flex', gap: 4 }}>
                  <button className="dt-btn dt-btn-secondary" style={{ height: 30, padding: '0 10px', fontSize: 12 }}>Message</button>
                  <button className="dt-iconbtn"><Ico.more/></button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right column — activity */}
        <aside>
          <div className="dt-card" style={{ padding: 18, marginBottom: 16 }}>
            <h3 className="dt-h2" style={{ fontSize: 15, marginBottom: 12 }}>Activity</h3>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
              {ACTIVITY.map((a, i) => (
                <div key={i} style={{ display: 'flex', gap: 10, alignItems: 'flex-start' }}>
                  <Avatar size={28} initials={a.initials} color={a.avatar}/>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: 12.5, lineHeight: 1.4 }}>
                      <strong>{a.who}</strong>
                      <span style={{ color: 'var(--muted)' }}> {a.text}</span>
                    </div>
                    <div style={{ fontSize: 10.5, color: 'var(--muted-2)', marginTop: 2 }} className="mono">{a.ago.toUpperCase()} AGO</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="dt-card" style={{ padding: 18 }}>
            <h3 className="dt-h2" style={{ fontSize: 15, marginBottom: 12 }}>Pending invites <span style={{color:'var(--muted-2)', fontWeight: 500, marginLeft: 4}}>2</span></h3>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {[
                { email: 'aria@cookhaus.com', sent: '2 days ago' },
                { email: 'mei.zhang@gmail.com', sent: '5 days ago' },
              ].map((inv, i) => (
                <div key={i} style={{ display: 'flex', gap: 8, alignItems: 'center', padding: '8px 0', borderBottom: i === 0 ? '1px solid var(--border)' : 0 }}>
                  <div style={{ width: 28, height: 28, borderRadius: 99, background: 'var(--surface-2)',
                    display:'flex', alignItems:'center', justifyContent:'center', fontSize: 13, color: 'var(--muted)' }}>✉</div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontSize: 12.5, fontWeight: 500, whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis' }}>{inv.email}</div>
                    <div style={{ fontSize: 11, color: 'var(--muted)' }}>Sent {inv.sent}</div>
                  </div>
                  <button className="dt-btn dt-btn-ghost" style={{ height: 26, padding: '0 8px', fontSize: 11.5 }}>Resend</button>
                </div>
              ))}
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
}

Object.assign(window, { DTSidebar, DTTopBar, DTDiscover, DTGuideCard, DTLibrary, DTTeam });
