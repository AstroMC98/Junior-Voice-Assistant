// Junior Desktop — Main App

const DT_DEFAULTS = /*EDITMODE-BEGIN*/{
  "theme": "light",
  "accent": "amber",
  "waveStyle": "bars",
  "density": "comfortable",
  "showChrome": true,
  "startScreen": "discover"
}/*EDITMODE-END*/;

function JuniorDesktopApp() {
  const [t, setTweak] = useTweaks(DT_DEFAULTS);

  const [screen, setScreen] = React.useState(t.startScreen || 'discover');
  const [guide, setGuide] = React.useState(GUIDES[0]);
  const [search, setSearch] = React.useState('');
  const [category, setCategory] = React.useState('all');
  const [authed, setAuthed] = React.useState(true);
  const [sessionOpen, setSessionOpen] = React.useState(false);

  // auto-scale to viewport
  const [scale, setScale] = React.useState(1);
  React.useEffect(() => {
    const compute = () => {
      const sx = (window.innerWidth - 32) / 1440;
      const sy = (window.innerHeight - 32) / 880;
      setScale(Math.min(1, sx, sy));
    };
    compute();
    window.addEventListener('resize', compute);
    return () => window.removeEventListener('resize', compute);
  }, []);

  const onNav = (id, catFilter) => {
    if (id === 'create') {
      setScreen('create');
      return;
    }
    if (id === 'discover' && catFilter) setCategory(catFilter);
    if (id === 'discover') setSearch('');
    setScreen(id);
  };

  const openGuide = (g) => {
    setGuide(g);
    setScreen('guide');
  };

  const isDark = t.theme === 'dark';
  const themeClass = `theme-${t.theme} accent-${t.accent}`;

  // Page title from screen
  const titleFor = (s) => ({
    discover: 'Discover',
    library: 'Library',
    team: 'Team',
    profile: 'Settings',
    create: 'New guide',
    guide: guide.title,
    session: `Voice session · ${guide.title}`,
  })[s] || 'Junior';

  const urlFor = (s) => ({
    discover: 'junior.app/discover',
    library:  'junior.app/library',
    team:     'junior.app/team',
    profile:  'junior.app/settings',
    create:   'junior.app/new',
    guide:    `junior.app/g/${guide.slug}`,
    session:  `junior.app/g/${guide.slug}/run`,
  })[s] || 'junior.app';

  const renderScreen = () => {
    if (sessionOpen) {
      return <DTSession guide={guide} onClose={() => setSessionOpen(false)} waveStyle={t.waveStyle}/>;
    }
    switch (screen) {
      case 'discover':
        return <DTDiscover onOpenGuide={openGuide} search={search}
          filterCategory={category} onFilterCategory={setCategory}/>;
      case 'library':
        return <DTLibrary onOpenGuide={openGuide}/>;
      case 'team':
        return <DTTeam/>;
      case 'profile':
        return <DTProfile onLogout={() => setAuthed(false)}
          themeDark={isDark} onTheme={(d) => setTweak('theme', d ? 'dark' : 'light')}
          accent={t.accent} onAccent={(v) => setTweak('accent', v)}/>;
      case 'guide':
        return <DTGuideDetail guide={guide}
          onBack={() => setScreen('discover')}
          onStart={() => setSessionOpen(true)}
          onFork={() => alert('Forked!')}/>;
      case 'create':
        return <DTCreate onBack={() => setScreen('discover')}
          onCreated={() => { setScreen('discover'); setSessionOpen(true); }}/>;
      default:
        return null;
    }
  };

  const appBody = (
    <div className={`dt ${themeClass}`} style={{ width: '100%', height: '100%' }}>
      <div className="dt-app">
        {!sessionOpen && (
          <>
            <DTSidebar active={screen} screen={screen}
              onNav={onNav} onOpenGuide={openGuide}/>
            <DTTopBar title={titleFor(screen)} search={search} onSearch={setSearch}
              themeDark={isDark} onTheme={(d) => setTweak('theme', d ? 'dark' : 'light')}
              accent={t.accent} onAccent={(v) => setTweak('accent', v)}/>
          </>
        )}
        <div className="dt-main" style={{
          gridRow: sessionOpen ? '1 / -1' : '2',
          gridColumn: sessionOpen ? '1 / -1' : '2',
          padding: 0,
        }}>
          {renderScreen()}
        </div>
      </div>
    </div>
  );

  // outer page — browser chrome frame
  return (
    <div className={themeClass} style={{
      minHeight: '100vh', width: '100%',
      background: isDark
        ? 'radial-gradient(ellipse at top, #2a2620 0%, #0a0908 60%)'
        : 'radial-gradient(ellipse at top, #e5e1d4 0%, #b8b1a0 60%)',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      padding: 0,
      overflow: 'hidden',
    }}>
      {t.showChrome ? (
        <div style={{
          width: 1440 * scale, height: 880 * scale,
          flexShrink: 0,
        }}>
          <div style={{
            width: 1440, height: 880,
            transform: `scale(${scale})`,
            transformOrigin: 'top left',
          }}>
            <ChromeWindow
              width={1440} height={880}
              url={urlFor(sessionOpen ? 'session' : screen)}
              tabs={[
                { title: 'Junior — ' + titleFor(sessionOpen ? 'session' : screen) },
                { title: 'KTANE Manual' },
                { title: 'GitHub' },
              ]}
              activeIndex={0}>
              {appBody}
            </ChromeWindow>
          </div>
        </div>
      ) : (
        <div style={{ width: '100vw', height: '100vh' }}>{appBody}</div>
      )}

      {/* Tweaks panel */}
      <TweaksPanel title="Tweaks" noDeckControls>
        <TweakSection label="Theme">
          <TweakRadio label="Mode" value={t.theme}
            options={[{value:'light',label:'Light'},{value:'dark',label:'Dark'}]}
            onChange={(v) => setTweak('theme', v)} />
          <TweakColor label="Accent" value={t.accent}
            options={[
              { value: 'amber', color: '#F26B3A' },
              { value: 'mint',  color: '#2DBE7A' },
              { value: 'iris',  color: '#5B6CFF' },
            ]}
            onChange={(v) => setTweak('accent', v)} />
        </TweakSection>

        <TweakSection label="Voice session">
          <TweakRadio label="Waveform" value={t.waveStyle}
            options={[
              {value:'bars', label:'Bars'},
              {value:'line', label:'Line'},
              {value:'ring', label:'Ring'},
            ]}
            onChange={(v) => setTweak('waveStyle', v)} />
          <TweakButton label="Open KTANE session" onClick={() => {
            setGuide(GUIDES[0]);
            setSessionOpen(true);
          }}/>
          <TweakButton label="Close session" secondary onClick={() => setSessionOpen(false)}/>
        </TweakSection>

        <TweakSection label="Frame">
          <TweakToggle label="Show browser chrome" value={t.showChrome}
            onChange={(v) => setTweak('showChrome', v)}/>
        </TweakSection>

        <TweakSection label="Jump to screen">
          <TweakSelect label="Screen" value={screen}
            options={[
              { value: 'discover', label: 'Discover' },
              { value: 'library',  label: 'Library' },
              { value: 'team',     label: 'Team' },
              { value: 'profile',  label: 'Settings' },
              { value: 'guide',    label: 'Guide detail' },
              { value: 'create',   label: 'New guide' },
            ]}
            onChange={(v) => { setSessionOpen(false); setScreen(v); }}/>
        </TweakSection>
      </TweaksPanel>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<JuniorDesktopApp/>);
