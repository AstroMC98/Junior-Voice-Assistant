// Landing / Onboarding / Login screens

function ScreenLanding({ onContinue, onLogin }) {
  return (
    <div className="app-scroll" style={{ display: 'flex', flexDirection: 'column' }}>
      {/* hero */}
      <div style={{
        position: 'relative', flex: 1, minHeight: 480,
        padding: '80px 28px 32px',
        background: 'linear-gradient(180deg, var(--accent-soft) 0%, var(--bg) 65%)',
        overflow: 'hidden',
      }}>
        {/* abstract waveform mark */}
        <div style={{
          position: 'absolute', top: 80, right: -40, width: 260, height: 260,
          borderRadius: '50%',
          background: 'radial-gradient(circle, color-mix(in oklab, var(--accent) 30%, transparent) 0%, transparent 70%)',
          filter: 'blur(20px)',
        }}/>

        <div style={{
          display: 'inline-flex', alignItems: 'center', gap: 8,
          padding: '6px 12px', borderRadius: 99,
          background: 'var(--surface)', border: '1px solid var(--border)',
          fontSize: 12, fontWeight: 500, color: 'var(--muted)',
        }}>
          <span style={{ display: 'inline-block', width: 6, height: 6, borderRadius: 99, background: 'var(--accent)' }}/>
          v1.2 — KTANE module support
        </div>

        <h1 style={{
          margin: '28px 0 12px',
          fontFamily: 'var(--font-display)', fontSize: 44,
          fontWeight: 600, letterSpacing: '-0.035em', lineHeight: 0.98,
          color: 'var(--ink)',
        }}>
          A voice that<br />reads any guide<br />
          <span style={{ color: 'var(--accent)' }}>so you don't have to.</span>
        </h1>
        <p style={{ fontSize: 15.5, lineHeight: 1.45, color: 'var(--muted)', maxWidth: 320, margin: '0 0 32px' }}>
          Upload a recipe, manual, or PDF. Junior reads it aloud, answers questions, and shows you the right diagram — hands-free.
        </p>

        {/* visualizer card */}
        <div style={{
          background: 'var(--surface)', borderRadius: 22, padding: 18,
          border: '1px solid var(--border)', boxShadow: 'var(--shadow-card)',
          marginBottom: 24,
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 14 }}>
            <div style={{
              width: 36, height: 36, borderRadius: 12,
              background: 'var(--accent)', color: '#fff',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}>
              <Ico.micFill style={{width:18,height:18}}/>
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 13, fontWeight: 600 }}>Junior is listening</div>
              <div style={{ fontSize: 11, color: 'var(--muted)' }} className="mono">SOURDOUGH PIZZA · STEP 4/12</div>
            </div>
            <div className="tag tag-live">● LIVE</div>
          </div>
          <Waveform active height={28} bars={36}/>
          <div style={{ fontSize: 13, color: 'var(--ink-2)', marginTop: 12, lineHeight: 1.4 }}>
            <span style={{ color: 'var(--muted)' }} className="mono">"</span>
            How long do I rest the dough after the stretch and fold?
            <span style={{ color: 'var(--muted)' }} className="mono">"</span>
          </div>
        </div>
      </div>

      {/* feature strip */}
      <div style={{ padding: '8px 28px 24px', display: 'flex', flexDirection: 'column', gap: 14 }}>
        {[
          { ico: <Ico.mic style={{width:18, height:18}}/>, h: 'Voice-first sessions',  s: 'Step through any guide while your hands stay busy.' },
          { ico: <Ico.cam style={{width:18, height:18}}/>, h: 'Photo progress checks', s: 'Snap a quick photo — Junior tells you if you nailed it.' },
          { ico: <Ico.fork style={{width:18, height:18}}/>, h: 'Share & fork',          s: 'Every guide gets a link. Recipients tweak their own copy.' },
        ].map((f, i) => (
          <div key={i} style={{ display: 'flex', gap: 14, alignItems: 'flex-start' }}>
            <div style={{
              width: 36, height: 36, borderRadius: 10,
              background: 'var(--surface-2)', border: '1px solid var(--border)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              color: 'var(--accent)', flexShrink: 0,
            }}>{f.ico}</div>
            <div>
              <div style={{ fontSize: 14.5, fontWeight: 600, letterSpacing: '-0.01em' }}>{f.h}</div>
              <div style={{ fontSize: 13, color: 'var(--muted)', marginTop: 2, lineHeight: 1.35 }}>{f.s}</div>
            </div>
          </div>
        ))}
      </div>

      {/* CTAs */}
      <div style={{ padding: '0 20px 32px', display: 'flex', flexDirection: 'column', gap: 10 }}>
        <button className="btn btn-primary btn-lg btn-block" onClick={onContinue}>
          Get started — it's free
        </button>
        <button className="btn btn-ghost btn-block" onClick={onLogin} style={{ color: 'var(--muted)' }}>
          I already have an account
        </button>
      </div>
    </div>
  );
}

function ScreenLogin({ onSuccess, onBack }) {
  const [email, setEmail] = React.useState('sam@junior.app');
  const [pw, setPw] = React.useState('••••••••••');

  return (
    <div className="app-scroll">
      <ScreenHeader
        title="Welcome back"
        sub="Sign in to your guides"
        left={<button onClick={onBack} style={{padding:4, marginLeft:-4}}><Ico.chevL/></button>}
      />
      <div style={{ padding: '8px 20px 24px', display: 'flex', flexDirection: 'column', gap: 14 }}>
        <button className="btn btn-secondary btn-lg btn-block" onClick={onSuccess}>
          <Ico.google /> Continue with Google
        </button>
        <button className="btn btn-secondary btn-lg btn-block" onClick={onSuccess}>
          <Ico.apple /> Continue with Apple
        </button>

        <div style={{ display: 'flex', alignItems: 'center', gap: 12, margin: '8px 0', color: 'var(--muted)', fontSize: 12 }}>
          <div className="divider" style={{ flex: 1 }}/>
          OR EMAIL
          <div className="divider" style={{ flex: 1 }}/>
        </div>

        <div className="field field-lg">
          <span style={{ color: 'var(--muted)', fontSize: 13 }}>✉</span>
          <input value={email} onChange={e => setEmail(e.target.value)} placeholder="Email"/>
        </div>
        <div className="field field-lg">
          <span style={{ color: 'var(--muted)', fontSize: 13 }}>🔒</span>
          <input value={pw} onChange={e => setPw(e.target.value)} type="password" placeholder="Password"/>
        </div>
        <button className="btn btn-primary btn-lg btn-block" onClick={onSuccess}>
          Sign in <Ico.arrow style={{width:18,height:18}}/>
        </button>
        <div style={{ textAlign: 'center', fontSize: 13, color: 'var(--muted)', marginTop: 4 }}>
          Forgot password?
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { ScreenLanding, ScreenLogin });
