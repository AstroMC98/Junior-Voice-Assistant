// Guide detail + Create screens

function ScreenGuideDetail({ guide, onBack, onStart, onFork }) {
  const [stepOpen, setStepOpen] = React.useState(null);
  return (
    <div className="app-scroll" style={{ background: 'var(--bg)' }}>
      {/* hero */}
      <div style={{
        position: 'relative', height: 320,
        background: guide.bg, overflow: 'hidden',
      }}>
        <div style={{
          position: 'absolute', inset: 0,
          background: 'linear-gradient(180deg, rgba(0,0,0,0.25) 0%, transparent 30%, rgba(0,0,0,0.7) 100%)',
        }}/>
        {/* nav */}
        <div style={{
          position: 'absolute', top: 56, left: 16, right: 16,
          display: 'flex', justifyContent: 'space-between',
        }}>
          <button onClick={onBack} style={{
            width: 36, height: 36, borderRadius: 99,
            background: 'rgba(0,0,0,0.35)', backdropFilter: 'blur(12px)',
            color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}><Ico.chevL/></button>
          <div style={{ display: 'flex', gap: 6 }}>
            <button style={{
              width: 36, height: 36, borderRadius: 99,
              background: 'rgba(0,0,0,0.35)', backdropFilter: 'blur(12px)',
              color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}><Ico.share/></button>
            <button style={{
              width: 36, height: 36, borderRadius: 99,
              background: 'rgba(0,0,0,0.35)', backdropFilter: 'blur(12px)',
              color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}><Ico.more/></button>
          </div>
        </div>

        {/* big glyph */}
        <div style={{
          position: 'absolute', top: 110, left: '50%', transform: 'translateX(-50%)',
          fontSize: 80, filter: 'drop-shadow(0 6px 20px rgba(0,0,0,0.4))',
        }}>{guide.glyph}</div>

        <div style={{
          position: 'absolute', bottom: 18, left: 20, right: 20, color: '#fff',
        }}>
          <div style={{ display: 'flex', gap: 6, marginBottom: 8 }}>
            <span className="tag" style={{ background: 'rgba(255,255,255,0.2)', color: '#fff', backdropFilter: 'blur(10px)' }}>
              {CATEGORIES.find(c => c.id === guide.category)?.label}
            </span>
            <span className="tag" style={{ background: 'rgba(255,255,255,0.2)', color: '#fff', backdropFilter: 'blur(10px)' }}>
              {guide.source}
            </span>
          </div>
          <h1 style={{
            margin: 0, fontSize: 26, fontWeight: 600, letterSpacing: '-0.02em', lineHeight: 1.1,
          }}>{guide.title}</h1>
          <p style={{ margin: '6px 0 0', fontSize: 14, opacity: 0.92 }}>{guide.subtitle}</p>
        </div>
      </div>

      {/* stats strip */}
      <div style={{
        margin: '-16px 20px 0', position: 'relative', zIndex: 2,
        background: 'var(--surface)', borderRadius: 18, padding: '14px 16px',
        display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 10,
        border: '1px solid var(--border)', boxShadow: 'var(--shadow-card)',
      }}>
        {[
          { l: 'Steps',    v: guide.stepsCount },
          { l: 'Time',     v: guide.duration },
          { l: 'Rating',   v: `★ ${guide.rating}` },
          { l: 'Runs',     v: `${(guide.runs/1000).toFixed(1)}k` },
        ].map((s, i) => (
          <div key={i} style={{ textAlign: 'center' }}>
            <div style={{ fontSize: 16, fontWeight: 600, letterSpacing: '-0.01em' }}>{s.v}</div>
            <div style={{ fontSize: 10, color: 'var(--muted)', textTransform: 'uppercase', letterSpacing: 0.06, marginTop: 2 }} className="mono">{s.l}</div>
          </div>
        ))}
      </div>

      {/* author + description */}
      <div style={{ padding: '20px 20px 0' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 14 }}>
          <Avatar size={40} initials={guide.author.initials} color={guide.author.avatar}/>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 13.5, fontWeight: 600 }}>{guide.author.name}</div>
            <div style={{ fontSize: 12, color: 'var(--muted)' }}>
              Created · {guide.sourceLabel || guide.source}
            </div>
          </div>
          <button className="btn btn-secondary btn-sm">Follow</button>
        </div>

        <p style={{ fontSize: 14, lineHeight: 1.5, color: 'var(--ink-2)', margin: 0 }}>
          {guide.description}
        </p>

        <div style={{ display: 'flex', gap: 6, marginTop: 14, flexWrap: 'wrap' }}>
          {guide.tags?.map(t => (
            <span key={t} className="chip" style={{ height: 26, fontSize: 11.5 }}>#{t}</span>
          ))}
        </div>
      </div>

      {/* steps preview */}
      <div className="sec-title">
        <h2>Steps</h2>
        <span className="more">{guide.stepsCount} total</span>
      </div>
      <div style={{ padding: '0 20px', display: 'flex', flexDirection: 'column', gap: 6 }}>
        {guide.steps.slice(0, 6).map(step => (
          <button key={step.i} onClick={() => setStepOpen(step)} style={{
            display: 'flex', alignItems: 'flex-start', gap: 12, padding: '12px 14px',
            background: 'var(--surface)', border: '1px solid var(--border)',
            borderRadius: 14, textAlign: 'left',
          }}>
            <div style={{
              width: 28, height: 28, borderRadius: 8,
              background: 'var(--surface-2)', border: '1px solid var(--border)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontSize: 12, fontWeight: 600,
            }} className="mono stepnum">{String(step.i).padStart(2, '0')}</div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: 14, fontWeight: 600, letterSpacing: '-0.005em' }}>{step.title}</div>
              <div style={{ fontSize: 12.5, color: 'var(--muted)', marginTop: 2,
                display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden' }}>
                {step.body}
              </div>
            </div>
            <Ico.chev style={{ color: 'var(--muted-2)', flexShrink: 0, marginTop: 4 }}/>
          </button>
        ))}
      </div>

      {/* community */}
      <div className="sec-title" style={{ marginTop: 26 }}>
        <h2>Community</h2>
      </div>
      <div style={{ padding: '0 20px', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
        <CommunityStat label="Forks" value={guide.forks} icon={<Ico.fork/>}/>
        <CommunityStat label="Avg session" value="11m 24s" icon={<Ico.clock/>}/>
      </div>

      <div style={{ height: 120 }}/>

      {/* Fixed CTA bar */}
      <div style={{
        position: 'absolute', bottom: 0, left: 0, right: 0,
        padding: '14px 20px 32px',
        background: 'linear-gradient(180deg, transparent, var(--bg) 40%)',
        display: 'flex', gap: 10, zIndex: 5,
      }}>
        <button className="btn btn-secondary btn-lg" onClick={onFork} style={{ padding: '0 16px' }}>
          <Ico.fork/> Fork
        </button>
        <button className="btn btn-primary btn-lg btn-block" onClick={onStart} style={{ flex: 1 }}>
          <Ico.mic style={{width:18,height:18}}/> Start voice session
        </button>
      </div>
    </div>
  );
}

function CommunityStat({ label, value, icon }) {
  return (
    <div className="card card-pad" style={{ padding: 14 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 11, color: 'var(--muted)', textTransform: 'uppercase', letterSpacing: 0.04 }} className="mono">
        {icon} {label}
      </div>
      <div style={{ fontSize: 22, fontWeight: 600, letterSpacing: '-0.02em', marginTop: 6 }}>{value}</div>
    </div>
  );
}

// ─── Create guide ────────────────────────────────────────────
function ScreenCreate({ onBack, onCreated }) {
  const [source, setSource] = React.useState('pdf');
  const [title, setTitle] = React.useState('');
  const [category, setCategory] = React.useState('cooking');
  const [stage, setStage] = React.useState('input'); // input | processing | done

  const sources = [
    { id: 'pdf', label: 'PDF',      icon: <Ico.pdf/>,  hint: 'Upload a PDF (recipe, manual, textbook).' },
    { id: 'url', label: 'URL',      icon: <Ico.link/>, hint: 'Paste a recipe or article URL.' },
    { id: 'cam', label: 'Camera',   icon: <Ico.cam/>,  hint: 'Photograph a physical book or printout.' },
  ];

  React.useEffect(() => {
    if (stage === 'processing') {
      const t = setTimeout(() => setStage('done'), 3200);
      return () => clearTimeout(t);
    }
  }, [stage]);

  if (stage === 'processing') {
    return <ProcessingView onCancel={() => setStage('input')} />;
  }
  if (stage === 'done') {
    return <CreatedView onDone={onCreated} title={title || 'New Guide'} />;
  }

  return (
    <div className="app-scroll">
      <ScreenHeader
        title="New guide"
        sub="Junior will extract the steps."
        left={<button onClick={onBack} style={{padding:4, marginLeft:-4}}><Ico.close/></button>}
      />

      <div style={{ padding: '0 20px 16px' }}>
        <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--muted)', marginBottom: 10, textTransform: 'uppercase', letterSpacing: 0.04 }} className="mono">
          1 · Choose source
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 8 }}>
          {sources.map(s => (
            <button key={s.id} onClick={() => setSource(s.id)} style={{
              padding: '14px 8px',
              background: source === s.id ? 'var(--accent-soft)' : 'var(--surface)',
              border: `1px solid ${source === s.id ? 'var(--accent)' : 'var(--border)'}`,
              borderRadius: 14,
              display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8,
              color: source === s.id ? 'var(--accent-ink)' : 'var(--ink)',
            }}>
              <div style={{ color: source === s.id ? 'var(--accent)' : 'var(--muted)' }}>{s.icon}</div>
              <div style={{ fontSize: 12.5, fontWeight: 600 }}>{s.label}</div>
            </button>
          ))}
        </div>
        <div style={{ fontSize: 12, color: 'var(--muted)', marginTop: 8 }}>
          {sources.find(s => s.id === source).hint}
        </div>
      </div>

      {/* file dropzone */}
      <div style={{ padding: '0 20px 16px' }}>
        {source === 'pdf' && <Dropzone />}
        {source === 'url' && (
          <div className="field field-lg">
            <Ico.link style={{color:'var(--muted)'}}/>
            <input placeholder="https://bombmanual.com" />
          </div>
        )}
        {source === 'cam' && <CameraCapture />}
      </div>

      <div style={{ padding: '0 20px 16px' }}>
        <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--muted)', marginBottom: 10, textTransform: 'uppercase', letterSpacing: 0.04 }} className="mono">
          2 · Describe it
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          <div className="field field-lg">
            <input placeholder="Guide title" value={title} onChange={e => setTitle(e.target.value)}/>
          </div>
          <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
            {CATEGORIES.map(c => (
              <button key={c.id} onClick={() => setCategory(c.id)}
                className={`chip ${category === c.id ? 'chip-active' : ''}`}
                style={{ fontSize: 12.5 }}>
                {c.emoji} {c.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div style={{ padding: '0 20px 16px' }}>
        <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--muted)', marginBottom: 10, textTransform: 'uppercase', letterSpacing: 0.04 }} className="mono">
          3 · Voice settings
        </div>
        <div className="card" style={{ overflow: 'hidden' }}>
          <SettingRow label="Voice"     value="Junior — warm" />
          <SettingRow label="Speed"     value="1.0×" />
          <SettingRow label="Visibility" value="🔗 Public" last />
        </div>
      </div>

      <div style={{ padding: '8px 20px 32px' }}>
        <button className="btn btn-primary btn-lg btn-block" onClick={() => setStage('processing')}>
          <Ico.spark style={{width:16,height:16}}/> Process with Claude
        </button>
      </div>
    </div>
  );
}

function SettingRow({ label, value, last }) {
  return (
    <div style={{
      padding: '14px 16px',
      borderBottom: last ? 0 : '1px solid var(--border)',
      display: 'flex', justifyContent: 'space-between', alignItems: 'center',
    }}>
      <div style={{ fontSize: 14 }}>{label}</div>
      <div style={{ fontSize: 14, color: 'var(--muted)', display: 'flex', alignItems: 'center', gap: 6 }}>
        {value} <Ico.chev style={{ color: 'var(--muted-2)' }}/>
      </div>
    </div>
  );
}

function Dropzone() {
  return (
    <div style={{
      padding: '32px 16px',
      border: '1.5px dashed var(--border-strong)',
      borderRadius: 14,
      textAlign: 'center', background: 'var(--surface-2)',
    }}>
      <div style={{ fontSize: 32, marginBottom: 8 }}>📄</div>
      <div style={{ fontSize: 14, fontWeight: 600, marginBottom: 4 }}>Drop a PDF here</div>
      <div style={{ fontSize: 12, color: 'var(--muted)', marginBottom: 12 }}>
        Up to 50 MB · scanned PDFs supported
      </div>
      <button className="btn btn-secondary btn-sm">Choose file</button>
    </div>
  );
}

function CameraCapture() {
  return (
    <div style={{
      padding: 16, background: 'var(--surface-2)',
      border: '1px solid var(--border)', borderRadius: 14,
      display: 'flex', gap: 12, alignItems: 'center',
    }}>
      <div style={{
        width: 64, height: 64, borderRadius: 12,
        background: 'linear-gradient(135deg, #18181b, #3f3f46)',
        display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff',
      }}><Ico.camera/></div>
      <div style={{ flex: 1 }}>
        <div style={{ fontSize: 13.5, fontWeight: 600 }}>Photograph the manual</div>
        <div style={{ fontSize: 12, color: 'var(--muted)', marginTop: 2 }}>Up to 30 pages, well-lit.</div>
      </div>
      <button className="btn btn-secondary btn-sm">Open</button>
    </div>
  );
}

function ProcessingView({ onCancel }) {
  const [phase, setPhase] = React.useState(0);
  const phases = [
    'Reading source…',
    'Detecting steps…',
    'Generating crop boxes…',
    'Compiling voice script…',
  ];
  React.useEffect(() => {
    const id = setInterval(() => setPhase(p => Math.min(p + 1, phases.length - 1)), 700);
    return () => clearInterval(id);
  }, []);

  return (
    <div style={{ padding: '80px 28px', textAlign: 'center', height: '100%', display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
      <div style={{ position: 'relative', width: 100, height: 100, margin: '0 auto 28px' }}>
        <div style={{ position: 'absolute', inset: 0, borderRadius: '50%',
          background: 'var(--accent-soft)', animation: 'pulseRing 1.6s infinite' }}/>
        <div style={{
          position: 'absolute', inset: 12, borderRadius: '50%',
          background: 'var(--accent)', color: '#fff',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontSize: 36,
        }}>
          <Ico.spark style={{width: 32, height:32}}/>
        </div>
      </div>
      <div style={{ fontSize: 20, fontWeight: 600, letterSpacing: '-0.02em', marginBottom: 8 }}>
        Junior is reading your guide
      </div>
      <div style={{ fontSize: 14, color: 'var(--muted)', marginBottom: 28 }}>
        This usually takes 20–60 seconds
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 8, padding: '0 12px' }}>
        {phases.map((p, i) => (
          <div key={i} style={{
            display: 'flex', alignItems: 'center', gap: 10, padding: '10px 12px',
            background: i <= phase ? 'var(--surface)' : 'transparent',
            border: '1px solid', borderColor: i <= phase ? 'var(--border)' : 'transparent',
            borderRadius: 10,
            opacity: i <= phase ? 1 : 0.5,
            transition: 'all 0.3s',
          }}>
            <div style={{
              width: 18, height: 18, borderRadius: 99,
              background: i < phase ? 'var(--accent)' : i === phase ? 'var(--accent-soft)' : 'var(--surface-2)',
              border: '1px solid', borderColor: i <= phase ? 'var(--accent)' : 'var(--border)',
              color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center',
              flexShrink: 0,
            }}>
              {i < phase && <Ico.check style={{width:11, height:11}}/>}
              {i === phase && <div style={{width:6, height:6, borderRadius: 99, background: 'var(--accent)'}}/>}
            </div>
            <div style={{ fontSize: 13.5, textAlign: 'left', flex: 1 }}>{p}</div>
          </div>
        ))}
      </div>

      <button onClick={onCancel} className="btn btn-ghost" style={{ marginTop: 24, color: 'var(--muted)' }}>
        Cancel
      </button>
    </div>
  );
}

function CreatedView({ onDone, title }) {
  return (
    <div style={{ padding: '80px 28px', textAlign: 'center', height: '100%', display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
      <div style={{
        width: 80, height: 80, borderRadius: 99, margin: '0 auto 24px',
        background: 'var(--accent)', color: '#fff',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
      }}>
        <Ico.check style={{width:36, height:36}}/>
      </div>
      <div style={{ fontSize: 24, fontWeight: 600, letterSpacing: '-0.02em', marginBottom: 8 }}>
        Guide ready
      </div>
      <div style={{ fontSize: 14, color: 'var(--muted)', marginBottom: 28 }}>
        9 steps extracted with diagrams.
      </div>

      <div className="card card-pad" style={{ textAlign: 'left', marginBottom: 24 }}>
        <div style={{ fontSize: 11, color: 'var(--muted)', textTransform: 'uppercase', letterSpacing: 0.06, marginBottom: 6 }} className="mono">SHARE LINK</div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 14 }}>
          <Ico.link style={{ color: 'var(--accent)' }}/>
          <span style={{ flex: 1, fontFamily: 'var(--font-mono)', fontSize: 13 }}>junior.app/g/abc123</span>
          <button className="btn btn-sm btn-secondary">Copy</button>
        </div>
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
        <button className="btn btn-primary btn-lg btn-block" onClick={onDone}>
          <Ico.mic style={{width:18,height:18}}/> Start session
        </button>
        <button className="btn btn-ghost btn-block" style={{ color: 'var(--muted)' }} onClick={onDone}>
          View guide
        </button>
      </div>
    </div>
  );
}

Object.assign(window, { ScreenGuideDetail, ScreenCreate });
