// Desktop voice session — 3-pane split view

function DTSession({ guide, onClose, waveStyle = 'bars' }) {
  // group steps by section (if guide has sections)
  const hasSections = guide.steps.some(s => s.section);
  // Pick a meaningful starting step — if the guide has Wires section, land mid-wires
  const initialIdx = React.useMemo(() => {
    if (!hasSections) return 2;
    const wiresIdx = guide.steps.findIndex(s => /6 wires/.test(s.title));
    return wiresIdx >= 0 ? wiresIdx : 2;
  }, [guide, hasSections]);

  const [stepIdx, setStepIdx] = React.useState(initialIdx);
  const step = guide.steps[stepIdx] || guide.steps[0];
  const [listening, setListening] = React.useState(true);
  const [transcript, setTranscript] = React.useState(CONVERSATION);
  const [photoOpen, setPhotoOpen] = React.useState(false);
  const [input, setInput] = React.useState('');
  const transcriptRef = React.useRef(null);

  const sections = React.useMemo(() => {
    if (!hasSections) return [];
    const map = new Map();
    guide.steps.forEach((s, idx) => {
      const sec = s.section || 'Steps';
      if (!map.has(sec)) map.set(sec, []);
      map.get(sec).push({ ...s, idx });
    });
    return [...map.entries()].map(([name, steps]) => ({ name, steps }));
  }, [guide, hasSections]);

  const currentSection = hasSections
    ? sections.find(sec => sec.steps.some(s => s.idx === stepIdx))?.name
    : null;

  // Separate setup (Bomb intel) and end (Final) from parallel modules
  const intelSection   = sections.find(s => s.name === 'Bomb intel');
  const finalSection   = sections.find(s => s.name === 'Final');
  const moduleSections = sections.filter(s => s !== intelSection && s !== finalSection);

  const intelDone = intelSection ? intelSection.steps.every(s => s.idx < stepIdx) : true;
  const moduleStatuses = moduleSections.map(m => {
    const allDone   = m.steps.every(s => s.idx < stepIdx);
    const anyActive = m.steps.some(s => s.idx === stepIdx);
    return {
      ...m,
      status: anyActive ? 'now' : allDone ? 'done' : 'idle',
      progress: m.steps.filter(s => s.idx < stepIdx).length,
      total: m.steps.length,
    };
  });
  const currentModule = moduleStatuses.find(m => m.status === 'now');
  const modulesSolved = moduleStatuses.filter(m => m.status === 'done').length;

  // Sub-step number within current section
  const sectionForCurrent = sections.find(s => s.steps.some(x => x.idx === stepIdx));
  const subStepIdx = sectionForCurrent
    ? sectionForCurrent.steps.findIndex(x => x.idx === stepIdx) + 1
    : null;
  const subStepTotal = sectionForCurrent ? sectionForCurrent.steps.length : null;

  const next = () => setStepIdx(i => Math.min(i + 1, guide.steps.length - 1));
  const prev = () => setStepIdx(i => Math.max(i - 1, 0));

  React.useEffect(() => {
    if (transcriptRef.current) transcriptRef.current.scrollTop = transcriptRef.current.scrollHeight;
  }, [transcript]);

  const sendMessage = (text) => {
    if (!text.trim()) return;
    setTranscript([...transcript, { role: 'user', t: '09:43:01', text }]);
    setInput('');
  };

  return (
    <div className="dt-session">
      {/* ── Left: Steps list ────────────────────────────────── */}
      <div className="dt-session-col" style={{ padding: '18px 16px' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
          <button onClick={onClose} className="dt-btn dt-btn-ghost" style={{ height: 30, padding: '0 8px', fontSize: 12 }}>
            <Ico.chevL style={{width:14,height:14}}/> Exit
          </button>
          <div className="mono" style={{ fontSize: 11, color: 'var(--muted)' }}>
            {stepIdx + 1} / {guide.steps.length}
          </div>
        </div>

        <div style={{
          padding: 12, marginBottom: 14,
          background: 'var(--surface)', borderRadius: 10, border: '1px solid var(--border)',
          display: 'flex', gap: 10, alignItems: 'center',
        }}>
          <div style={{
            width: 36, height: 36, borderRadius: 8, background: guide.bg,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: 18, flexShrink: 0,
          }}>{guide.glyph}</div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontSize: 12.5, fontWeight: 600, letterSpacing: '-0.005em',
              whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{guide.title}</div>
            <div style={{ fontSize: 10.5, color: 'var(--muted)' }} className="mono">
              {guide.stepsCount} STEPS · {guide.duration}
            </div>
          </div>
        </div>

        <div className="dt-eyebrow" style={{ padding: '0 4px 8px' }}>
          {hasSections ? `${sections.length - (finalSection?1:0) - (intelSection?1:0)} MODULES · ANY ORDER` : 'STEPS'}
        </div>

        {hasSections ? (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>

            {/* BOMB INTEL — setup checklist (always-first phase) */}
            {intelSection && (
              <div style={{
                padding: 10, background: 'var(--surface)',
                border: '1px solid var(--border)', borderRadius: 10,
              }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 6 }}>
                  <div className="mono" style={{
                    fontSize: 10.5, letterSpacing: 0.08, textTransform: 'uppercase',
                    color: 'var(--ink)', fontWeight: 600, flex: 1,
                  }}>Bomb intel</div>
                  <span className="mono" style={{ fontSize: 10, color: intelDone ? 'var(--accent)' : 'var(--muted)' }}>
                    {intelDone ? '✓ DONE' : `${intelSection.steps.filter(s => s.idx < stepIdx).length}/${intelSection.steps.length}`}
                  </span>
                </div>
                {intelSection.steps.map(s => {
                  const done = s.idx < stepIdx;
                  const now = s.idx === stepIdx;
                  return (
                    <button key={s.i} onClick={() => setStepIdx(s.idx)} style={{
                      width: '100%', textAlign: 'left',
                      display: 'flex', gap: 8, alignItems: 'center',
                      padding: '4px 0', fontSize: 11.5,
                      color: now ? 'var(--ink)' : done ? 'var(--muted)' : 'var(--ink-2)',
                      fontWeight: now ? 600 : 500,
                    }}>
                      <span style={{
                        width: 12, height: 12, borderRadius: 3, flexShrink: 0,
                        background: done ? 'var(--accent)' : now ? 'var(--accent-soft)' : 'transparent',
                        border: '1px solid', borderColor: done ? 'transparent' : now ? 'var(--accent)' : 'var(--border)',
                        display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
                        color: '#fff',
                      }}>{done && <Ico.check style={{width:8, height:8}}/>}</span>
                      <span style={{ flex: 1, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                        {s.title}
                      </span>
                    </button>
                  );
                })}
              </div>
            )}

            {/* MODULES — parallel grid */}
            {moduleSections.length > 0 && (
              <div>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0 4px 8px' }}>
                  <div className="mono" style={{ fontSize: 10, color: 'var(--muted)', letterSpacing: 0.08, textTransform: 'uppercase' }}>
                    Modules · pick any
                  </div>
                  <span className="mono" style={{ fontSize: 10, color: 'var(--muted)' }}>
                    {modulesSolved}/{moduleSections.length} solved
                  </span>
                </div>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6 }}>
                  {moduleStatuses.map(m => (
                    <ModuleCard key={m.name} module={m}
                      onClick={() => setStepIdx(m.steps[0].idx)} />
                  ))}
                </div>
              </div>
            )}

            {/* CURRENT MODULE — expanded sub-steps */}
            {currentModule && (
              <div style={{
                padding: 10, background: 'var(--accent-soft)',
                border: '1px solid var(--accent)', borderRadius: 10,
              }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 8 }}>
                  <span style={{
                    width: 8, height: 8, borderRadius: 99, background: 'var(--accent)',
                    animation: 'pulseRing 1.6s infinite',
                  }}/>
                  <div className="mono" style={{
                    fontSize: 10.5, letterSpacing: 0.08, textTransform: 'uppercase',
                    color: 'var(--accent-ink)', fontWeight: 700, flex: 1,
                  }}>Now: {currentModule.name}</div>
                  <span className="mono" style={{ fontSize: 10, color: 'var(--accent-ink)', opacity: 0.7 }}>
                    {currentModule.progress}/{currentModule.total}
                  </span>
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                  {currentModule.steps.map(s => (
                    <StepRow key={s.i} s={s} active={s.idx === stepIdx}
                      done={s.idx < stepIdx} onClick={() => setStepIdx(s.idx)}/>
                  ))}
                </div>
              </div>
            )}

            {/* Final phase */}
            {finalSection && (
              <div style={{ opacity: stepIdx >= finalSection.steps[0].idx ? 1 : 0.5 }}>
                <div className="dt-eyebrow" style={{ padding: '0 4px 6px' }}>FINAL</div>
                {finalSection.steps.map(s => {
                  const done = s.idx < stepIdx;
                  const now = s.idx === stepIdx;
                  return (
                    <button key={s.i} onClick={() => setStepIdx(s.idx)} style={{
                      width: '100%', textAlign: 'left',
                      display: 'flex', gap: 8, alignItems: 'center',
                      padding: '6px 8px', borderRadius: 6,
                      background: now ? 'var(--accent-soft)' : 'transparent',
                      fontSize: 12,
                      color: now ? 'var(--accent-ink)' : 'var(--ink-2)',
                      fontWeight: now ? 600 : 500,
                    }}>
                      <span style={{
                        width: 14, height: 14, borderRadius: 4, flexShrink: 0,
                        background: done ? 'var(--accent)' : 'transparent',
                        border: '1px solid', borderColor: done ? 'transparent' : 'var(--border)',
                        display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
                        color: '#fff',
                      }}>{done && <Ico.check style={{width:9, height:9}}/>}</span>
                      <span>{s.title}</span>
                    </button>
                  );
                })}
              </div>
            )}

          </div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
            {guide.steps.map((s, i) => (
              <StepRow key={s.i} s={{...s, idx: i}} active={i === stepIdx}
                done={i < stepIdx} onClick={() => setStepIdx(i)}/>
            ))}
          </div>
        )}
      </div>

      {/* ── Center: Big diagram + step ────────────────────────── */}
      <div className="dt-session-center">
        {/* top progress */}
        <div style={{ padding: '14px 24px 12px', borderBottom: '1px solid var(--border)' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
            <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
              <span className="tag tag-live" style={{ background: '#FF3B30' }}>● LIVE SESSION</span>
              <span style={{ fontSize: 12, color: 'var(--muted)' }} className="mono">04:23 ELAPSED · ~03:12 REMAINING</span>
            </div>
            <div style={{ display: 'flex', gap: 4 }}>
              <button className="dt-iconbtn" style={{ width: 32, height: 32 }} title="Settings"><Ico.setting style={{width:16,height:16}}/></button>
              <button className="dt-iconbtn" style={{ width: 32, height: 32 }} title="Share"><Ico.share/></button>
            </div>
          </div>
          {hasSections && moduleStatuses.length > 0 ? (
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <span className="mono" style={{ fontSize: 10, color: 'var(--muted)', letterSpacing: 0.06,
                textTransform: 'uppercase', whiteSpace: 'nowrap' }}>
                Bomb intel
                <span style={{
                  display: 'inline-flex', width: 14, height: 14, borderRadius: 4,
                  background: intelDone ? 'var(--accent)' : 'var(--surface-3)',
                  color: '#fff',
                  marginLeft: 6, verticalAlign: -3,
                  alignItems: 'center', justifyContent: 'center',
                }}>
                  {intelDone && <Ico.check style={{width:9, height:9}}/>}
                </span>
              </span>
              <span style={{ width: 1, height: 18, background: 'var(--border)' }}/>
              <span className="mono" style={{ fontSize: 10, color: 'var(--muted)', letterSpacing: 0.06,
                textTransform: 'uppercase', whiteSpace: 'nowrap' }}>
                Modules · {modulesSolved}/{moduleSections.length} solved
              </span>
              <div style={{ display: 'flex', gap: 4, flex: 1 }}>
                {moduleStatuses.map(m => (
                  <div key={m.name} title={m.name} style={{
                    flex: 1, height: 6, borderRadius: 3,
                    background: m.status === 'done' ? 'var(--accent)' :
                                m.status === 'now'  ? 'var(--accent)' : 'var(--surface-3)',
                    opacity: m.status === 'now' ? 0.5 : 1,
                    position: 'relative',
                  }}>
                    {m.status === 'now' && (
                      <div style={{
                        position: 'absolute', left: 0, top: 0, height: '100%',
                        width: `${(m.progress / m.total) * 100}%`,
                        background: 'var(--accent)', borderRadius: 3,
                      }}/>
                    )}
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <StepProgress total={guide.steps.length} current={stepIdx}/>
          )}
        </div>

        {/* main */}
        <div style={{ flex: 1, overflowY: 'auto', padding: '24px 32px' }}>
          {/* step header */}
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 12, marginBottom: 6, flexWrap: 'wrap' }}>
            {currentSection && (
              <span className="tag" style={{ background: 'var(--accent)', color: '#fff' }}>
                {currentSection.toUpperCase()}
              </span>
            )}
            {subStepIdx ? (
              <>
                <span className="tag tag-accent">STEP {subStepIdx} OF {subStepTotal}</span>
                <span style={{ fontSize: 12, color: 'var(--muted)' }} className="mono">IN THIS MODULE</span>
              </>
            ) : (
              <>
                <span className="tag tag-accent">STEP {String(step.i).padStart(2,'0')}</span>
                <span style={{ fontSize: 12, color: 'var(--muted)' }} className="mono">OF {guide.steps.length}</span>
              </>
            )}
          </div>
          <h2 style={{
            margin: '6px 0 10px',
            fontFamily: 'var(--font-display)',
            fontSize: 34, fontWeight: 600, letterSpacing: '-0.025em', lineHeight: 1.1,
          }}>{step.title}</h2>
          <p style={{ margin: '0 0 24px', fontSize: 16, lineHeight: 1.55, color: 'var(--ink-2)', maxWidth: 640 }}>
            {step.body}
          </p>

          {/* Diagram + crop */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 280px', gap: 16, marginBottom: 24 }}>
            <DTDiagram guide={guide} step={step}/>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              <div className="dt-card" style={{ padding: 14 }}>
                <div className="dt-eyebrow" style={{ marginBottom: 8 }}>AI CROP</div>
                <div style={{ fontSize: 12, color: 'var(--ink-2)', lineHeight: 1.4 }}>
                  Claude isolated the region of <span className="mono" style={{ color: 'var(--accent)' }}>{guide.sourceLabel}</span> most relevant to step {step.i}.
                </div>
                <div style={{ display: 'flex', gap: 4, marginTop: 10 }}>
                  <button className="dt-btn dt-btn-ghost" style={{ height: 26, padding: '0 8px', fontSize: 11.5 }}>Adjust crop</button>
                  <button className="dt-btn dt-btn-ghost" style={{ height: 26, padding: '0 8px', fontSize: 11.5 }}>See full page</button>
                </div>
              </div>

              <div className="dt-card" style={{ padding: 14 }}>
                <div className="dt-eyebrow" style={{ marginBottom: 8 }}>PROGRESS CHECK</div>
                <div style={{ fontSize: 12, color: 'var(--ink-2)', lineHeight: 1.4, marginBottom: 10 }}>
                  Snap a photo when you finish this step. Claude will tell you go or no-go.
                </div>
                <button onClick={() => setPhotoOpen(true)} className="dt-btn dt-btn-secondary" style={{ width: '100%' }}>
                  <Ico.camera/> Capture photo
                </button>
              </div>
            </div>
          </div>

          {/* Quick commands strip */}
          <div className="dt-eyebrow" style={{ marginBottom: 8 }}>QUICK COMMANDS · SAY OR TAP</div>
          <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
            {QUICK_CMDS.map(c => (
              <button key={c} onClick={() => sendMessage(c)} className="chip"
                style={{ height: 32, fontSize: 12.5 }}>
                <span className="mono" style={{ fontSize: 9, opacity: 0.55, marginRight: 4 }}>›</span>{c}
              </button>
            ))}
          </div>
        </div>

        {/* bottom mic dock */}
        <DTMicDock listening={listening} setListening={setListening}
          onPrev={prev} onNext={next} waveStyle={waveStyle}/>
      </div>

      {/* ── Right: Live transcript ────────────────────────── */}
      <div className="dt-session-col" style={{ display: 'flex', flexDirection: 'column' }}>
        <div style={{
          padding: '16px 18px 12px', borderBottom: '1px solid var(--border)',
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        }}>
          <div>
            <div style={{ fontSize: 13, fontWeight: 600 }}>Conversation</div>
            <div style={{ fontSize: 11, color: 'var(--muted)' }} className="mono">{transcript.length} TURNS · SAVED</div>
          </div>
          <button className="dt-iconbtn" style={{ width: 30, height: 30 }}><Ico.more/></button>
        </div>

        <div ref={transcriptRef} style={{ flex: 1, overflowY: 'auto', padding: 16, display: 'flex', flexDirection: 'column', gap: 10 }}>
          {transcript.map((m, i) => <DTBubble key={i} m={m} guide={guide} step={step}/>)}
          {listening && (
            <div style={{ alignSelf: 'flex-end', display: 'flex', gap: 4, padding: '8px 12px',
              background: 'var(--accent-soft)', color: 'var(--accent-ink)', borderRadius: 14, borderBottomRightRadius: 4 }}>
              <Dot d={0}/><Dot d={150}/><Dot d={300}/>
            </div>
          )}
        </div>

        {/* text input */}
        <div style={{ padding: 12, borderTop: '1px solid var(--border)' }}>
          <form onSubmit={(e) => { e.preventDefault(); sendMessage(input); }} style={{
            display: 'flex', alignItems: 'center', gap: 8,
            padding: '6px 8px 6px 14px',
            background: 'var(--surface-2)', border: '1px solid var(--border)',
            borderRadius: 10,
          }}>
            <input value={input} onChange={(e) => setInput(e.target.value)}
              placeholder="Type instead of speaking…"
              style={{ flex: 1, height: 30, border: 0, background: 'transparent', outline: 'none', fontSize: 13 }}/>
            <button type="submit" className="dt-iconbtn" style={{ width: 30, height: 30,
              background: input.trim() ? 'var(--accent)' : 'var(--surface-3)',
              color: input.trim() ? '#fff' : 'var(--muted)' }}>
              <Ico.send style={{width:14,height:14}}/>
            </button>
          </form>
        </div>
      </div>

      {/* Photo check modal */}
      {photoOpen && <DTPhotoModal guide={guide} step={step}
        onClose={() => setPhotoOpen(false)}
        onPass={() => { setPhotoOpen(false); next(); }} />}
    </div>
  );
}

function Dot({ d }) {
  return <span style={{
    width: 6, height: 6, borderRadius: 99, background: 'currentColor', opacity: 0.5,
    animation: `typing 1.2s ${d}ms infinite`,
  }}/>;
}

// ─── Diagram with AI crop overlay ───────────────────────────
function DTDiagram({ guide, step }) {
  return (
    <div style={{
      position: 'relative', borderRadius: 14, overflow: 'hidden',
      background: 'var(--surface-2)', border: '1px solid var(--border)',
      aspectRatio: '4/3', minHeight: 280,
    }}>
      {/* faux page tinted by guide bg */}
      <div style={{ position: 'absolute', inset: 0, background: guide.bg, opacity: 0.15 }}/>

      {/* fake page content */}
      <div style={{ position: 'absolute', inset: 0, padding: 28, fontFamily: 'var(--font-mono)',
        fontSize: 11, color: 'var(--ink-2)', opacity: 0.55 }}>
        <div style={{ fontWeight: 700, fontSize: 12, letterSpacing: 0.04, textTransform: 'uppercase', marginBottom: 14 }}>
          {guide.sourceLabel || 'Source'} — p.{Math.max(1, step.i)}
        </div>
        <div style={{ height: 5, width: '40%', background: 'currentColor', opacity: 0.5, marginBottom: 8 }}/>
        <div style={{ height: 5, width: '70%', background: 'currentColor', opacity: 0.3, marginBottom: 8 }}/>
        <div style={{ height: 5, width: '55%', background: 'currentColor', opacity: 0.3, marginBottom: 28 }}/>

        {guide.id === 'g_ktane' ? (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 14, padding: '8px 0' }}>
            {['#e63946','#3a86ff','#3a86ff','#ffd60a','#e63946','#fafafa'].map((c, i) => (
              <div key={i} style={{ height: 8, width: '70%', background: c, borderRadius: 99, opacity: 0.92 }}/>
            ))}
          </div>
        ) : (
          <div style={{ marginTop: 12, display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: 8 }}>
            {[...Array(12)].map((_,i)=>(
              <div key={i} style={{ aspectRatio: '1', borderRadius: 6,
                background: 'currentColor', opacity: 0.06 + (i%3)*0.04 }}/>
            ))}
          </div>
        )}
      </div>

      {/* AI crop overlay */}
      <div className="crop-box" style={{
        left: '10%', top: '36%', width: '64%', height: '42%',
      }}>
        <div className="crop-label">AI crop · step {step.i}</div>
      </div>

      {/* mini source label */}
      <div style={{
        position: 'absolute', bottom: 12, left: 16,
        display: 'flex', gap: 8, alignItems: 'center',
        padding: '4px 10px', background: 'rgba(0,0,0,0.5)',
        backdropFilter: 'blur(10px)', borderRadius: 99,
        color: '#fff', fontSize: 11,
      }} className="mono">
        📄 {guide.sourceLabel || 'page'} — p.{Math.max(1,step.i)}
      </div>
    </div>
  );
}

// ─── Transcript bubble (desktop) ────────────────────────────
function DTBubble({ m, guide, step }) {
  const isMe = m.role === 'user';
  const isAction = m.action === 'show_image';

  if (isAction) {
    return (
      <div style={{ alignSelf: 'flex-start', maxWidth: '95%', width: '100%' }}>
        <div style={{ fontSize: 10, color: 'var(--muted)', marginBottom: 4, padding: '0 4px' }} className="mono">
          JUNIOR · {m.t}
        </div>
        <div style={{
          padding: 10, background: 'var(--surface)', border: '1px solid var(--border)',
          borderRadius: 14, borderBottomLeftRadius: 4,
        }}>
          <div style={{ fontSize: 12.5, marginBottom: 8, color: 'var(--ink-2)', lineHeight: 1.4 }}>{m.text}</div>
          <div style={{
            position: 'relative', borderRadius: 8, overflow: 'hidden',
            aspectRatio: '4/3', background: 'var(--surface-2)',
            border: '1px solid var(--border)',
          }}>
            <div style={{ position: 'absolute', inset: 0, background: guide.bg, opacity: 0.2 }}/>
            <div style={{ position: 'absolute', inset: 12, fontFamily: 'var(--font-mono)', fontSize: 8, color: 'var(--muted)' }}>
              {guide.sourceLabel} · p.{step.i}
            </div>
            <div className="crop-box" style={{ left: '12%', top: '30%', width: '60%', height: '45%' }}>
              <div className="crop-label" style={{ fontSize: 8 }}>STEP {step.i}</div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div style={{
      alignSelf: isMe ? 'flex-end' : 'flex-start',
      maxWidth: '85%', display: 'flex', flexDirection: 'column', gap: 4,
    }}>
      <div style={{ fontSize: 10, color: 'var(--muted)', padding: '0 4px',
        textAlign: isMe ? 'right' : 'left' }} className="mono">
        {isMe ? 'YOU' : 'JUNIOR'} · {m.t}
      </div>
      <div style={{
        padding: '8px 12px',
        background: isMe ? 'var(--accent)' : 'var(--surface)',
        color: isMe ? '#fff' : 'var(--ink-2)',
        borderRadius: 14,
        borderBottomRightRadius: isMe ? 4 : 14,
        borderBottomLeftRadius: isMe ? 14 : 4,
        border: isMe ? 0 : '1px solid var(--border)',
        fontSize: 13, lineHeight: 1.4,
      }}>{m.text}</div>
    </div>
  );
}

// ─── Mic dock ────────────────────────────────────────────
function DTMicDock({ listening, setListening, onPrev, onNext, waveStyle }) {
  return (
    <div style={{
      padding: '16px 24px 20px', borderTop: '1px solid var(--border)',
      background: 'var(--surface)', display: 'flex', gap: 12, alignItems: 'center',
    }}>
      <button onClick={onPrev} className="dt-btn dt-btn-secondary" style={{ height: 44, padding: '0 14px' }}>
        <Ico.chevL/> Previous
      </button>

      <div style={{ flex: 1, position: 'relative', height: 56,
        background: 'var(--bg-2)', border: '1px solid var(--border)',
        borderRadius: 99, display: 'flex', alignItems: 'center', padding: '0 8px', gap: 10,
      }}>
        <button onClick={() => setListening(!listening)} className={listening ? 'pulse' : ''} style={{
          width: 42, height: 42, borderRadius: 99, flexShrink: 0,
          background: listening ? 'var(--accent)' : 'var(--surface-3)',
          color: listening ? '#fff' : 'var(--muted)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>
          {listening ? <Ico.micFill style={{width:20,height:20}}/> : <Ico.mic style={{width:20,height:20}}/>}
        </button>

        <div style={{ flex: 1, height: 32 }}>
          <Waveform active={listening} style={waveStyle} height={32}
            color="var(--accent)" bars={48}/>
        </div>

        <div style={{ paddingRight: 14, display: 'flex', alignItems: 'center', gap: 8 }}>
          <span className="mono" style={{ fontSize: 11, color: 'var(--muted)' }}>
            {listening ? '● LISTENING' : 'PAUSED'}
          </span>
          <div style={{ fontSize: 11, color: 'var(--muted-2)', fontFamily: 'var(--font-mono)' }}>
            <span className="kbd">⌘</span> <span className="kbd">␣</span>
          </div>
        </div>
      </div>

      <button onClick={onNext} className="dt-btn dt-btn-primary" style={{ height: 44, padding: '0 14px' }}>
        Next <Ico.chev style={{width:16,height:16}}/>
      </button>
    </div>
  );
}

// ─── Photo modal ────────────────────────────────────────
function DTPhotoModal({ guide, step, onClose, onPass }) {
  const [stage, setStage] = React.useState('capture');
  React.useEffect(() => {
    if (stage === 'review') {
      const t = setTimeout(() => setStage('result'), 1800);
      return () => clearTimeout(t);
    }
  }, [stage]);

  return (
    <div style={{
      position: 'absolute', inset: 0, zIndex: 200,
      background: 'rgba(0,0,0,0.55)', backdropFilter: 'blur(6px)',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      padding: 32,
    }} onClick={onClose}>
      <div onClick={(e) => e.stopPropagation()} className="dt-card" style={{
        background: 'var(--surface)', borderRadius: 18,
        width: 560, maxWidth: '100%', padding: 24,
        boxShadow: 'var(--shadow-pop)',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 }}>
          <div>
            <div className="dt-eyebrow">PROGRESS CHECK · STEP {String(step.i).padStart(2,'0')}</div>
            <h3 className="dt-h2" style={{ marginTop: 4 }}>{step.title}</h3>
          </div>
          <button onClick={onClose} className="dt-iconbtn"><Ico.close/></button>
        </div>

        {stage === 'capture' && (
          <>
            <div style={{
              width: '100%', height: 320, borderRadius: 14,
              background: 'radial-gradient(circle at center, #2a1810 0%, #000 100%)',
              position: 'relative', overflow: 'hidden', marginBottom: 16,
            }}>
              {[
                { t: 12, l: 12, brT: 2, brL: 2 },
                { t: 12, r: 12, brT: 2, brR: 2 },
                { b: 12, l: 12, brB: 2, brL: 2 },
                { b: 12, r: 12, brB: 2, brR: 2 },
              ].map((p, i) => (
                <div key={i} style={{
                  position: 'absolute', top: p.t, bottom: p.b, left: p.l, right: p.r,
                  width: 26, height: 26,
                  borderTop:    p.brT ? `${p.brT}px solid var(--accent)` : 0,
                  borderBottom: p.brB ? `${p.brB}px solid var(--accent)` : 0,
                  borderLeft:   p.brL ? `${p.brL}px solid var(--accent)` : 0,
                  borderRight:  p.brR ? `${p.brR}px solid var(--accent)` : 0,
                }}/>
              ))}
              <div style={{ position: 'absolute', top: 14, left: 14, fontSize: 11, color: 'rgba(255,255,255,0.8)' }} className="mono">
                ● 4K · ISO 800
              </div>
              <div style={{ position: 'absolute', bottom: 20, left: 0, right: 0, textAlign: 'center',
                fontSize: 13, color: 'rgba(255,255,255,0.8)' }}>
                Hold steady — fit the module in view
              </div>
            </div>
            <div style={{ display: 'flex', gap: 8 }}>
              <button onClick={onClose} className="dt-btn dt-btn-secondary dt-btn-lg" style={{ flex: 1 }}>Cancel</button>
              <button onClick={() => setStage('review')} className="dt-btn dt-btn-primary dt-btn-lg" style={{ flex: 1 }}>
                <Ico.camera/> Capture & analyze
              </button>
            </div>
          </>
        )}

        {stage === 'review' && (
          <div style={{ textAlign: 'center', padding: '40px 0' }}>
            <div style={{
              width: 80, height: 80, borderRadius: 20, margin: '0 auto 18px',
              background: 'var(--surface-2)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              animation: 'pulseRing 1.6s infinite',
            }}>
              <Ico.spark style={{width:36, height:36, color: 'var(--accent)'}}/>
            </div>
            <div style={{ fontSize: 17, fontWeight: 600 }}>Claude is analyzing the photo…</div>
            <div style={{ fontSize: 13, color: 'var(--muted)', marginTop: 4 }}>
              Comparing to step {step.i}: "{step.title}"
            </div>
          </div>
        )}

        {stage === 'result' && (
          <div>
            <div style={{
              padding: 16, borderRadius: 12,
              background: 'var(--accent-soft)', color: 'var(--accent-ink)',
              display: 'flex', gap: 12, alignItems: 'flex-start',
              marginBottom: 16,
            }}>
              <div style={{
                width: 36, height: 36, borderRadius: 99,
                background: 'var(--accent)', color: '#fff',
                display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
              }}>
                <Ico.check style={{width:20, height:20}}/>
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 15, fontWeight: 600, marginBottom: 4 }}>Looks good — advance</div>
                <div style={{ fontSize: 13, lineHeight: 1.4, opacity: 0.85 }}>
                  The yellow wire is cleanly severed and the rest are intact. Ready for step {step.i + 1}.
                </div>
              </div>
            </div>
            <div style={{ marginBottom: 18 }}>
              {[
                { ok: true, l: 'Correct wire cut' },
                { ok: true, l: 'Other wires undamaged' },
                { ok: false, l: 'Module still firmly attached' },
              ].map((c, i) => (
                <div key={i} style={{ display: 'flex', gap: 10, fontSize: 13.5, alignItems: 'center', padding: '8px 0',
                  borderBottom: i < 2 ? '1px solid var(--border)' : 0 }}>
                  <div style={{
                    width: 22, height: 22, borderRadius: 99, flexShrink: 0,
                    background: c.ok ? 'var(--accent)' : 'var(--surface-3)',
                    color: c.ok ? '#fff' : 'var(--muted)',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                  }}>
                    {c.ok ? <Ico.check style={{width:13, height:13}}/> : '?'}
                  </div>
                  <span style={{ color: c.ok ? 'var(--ink)' : 'var(--muted)' }}>{c.l}</span>
                </div>
              ))}
            </div>
            <div style={{ display: 'flex', gap: 10 }}>
              <button onClick={onClose} className="dt-btn dt-btn-secondary dt-btn-lg" style={{ flex: 1 }}>Retry</button>
              <button onClick={onPass} className="dt-btn dt-btn-primary dt-btn-lg" style={{ flex: 2 }}>
                Advance <Ico.arrow style={{width:16,height:16}}/>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

Object.assign(window, { DTSession, DTDiagram, DTBubble, DTMicDock, DTPhotoModal });

// ─── Step row (used inside both flat and sectioned step lists) ──
function StepRow({ s, active, done, onClick }) {
  return (
    <button onClick={onClick} style={{
      padding: '8px 8px',
      background: active ? 'var(--accent-soft)' : 'transparent',
      border: '1px solid', borderColor: active ? 'var(--accent)' : 'transparent',
      borderRadius: 8, textAlign: 'left',
      display: 'flex', gap: 10, alignItems: 'flex-start',
    }}>
      <div style={{
        width: 20, height: 20, borderRadius: 5, flexShrink: 0,
        background: done ? 'var(--accent)' : active ? 'var(--accent)' : 'var(--surface-2)',
        border: '1px solid', borderColor: done || active ? 'transparent' : 'var(--border)',
        color: done || active ? '#fff' : 'var(--muted)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontSize: 9.5, fontWeight: 600,
      }} className="mono">
        {done ? <Ico.check style={{width:10,height:10}}/> : String(s.i).padStart(2,'0')}
      </div>
      <div style={{ minWidth: 0, flex: 1 }}>
        <div style={{
          fontSize: 12.5, fontWeight: active ? 600 : 500, lineHeight: 1.3,
          color: active ? 'var(--accent-ink)' : 'var(--ink)',
        }}>{s.title}</div>
        {active && (
          <div className="mono" style={{ fontSize: 9.5, color: 'var(--accent-ink)',
            opacity: 0.65, marginTop: 2 }}>● NOW · LIVE</div>
        )}
      </div>
    </button>
  );
}

window.StepRow = StepRow;

// ─── Module card (parallel-pickable) ────────────────────────
const MODULE_ICONS = {
  'Wires module': '✂',
  'The Button':   '◉',
  'Keypads':      '⌗',
  'Simon Says':   '▣',
  'Memory':       '☷',
  'Morse code':   '·−',
  'Who\'s on First': '?',
  'Complicated Wires': '⌇',
};

function ModuleCard({ module, onClick }) {
  const { name, status, progress, total } = module;
  const isDone = status === 'done';
  const isNow  = status === 'now';

  return (
    <button onClick={onClick} style={{
      padding: 10,
      background: isNow ? 'var(--accent-soft)' : 'var(--surface)',
      border: '1px solid',
      borderColor: isNow ? 'var(--accent)' : isDone ? 'var(--accent)' : 'var(--border)',
      borderRadius: 9, textAlign: 'left',
      display: 'flex', flexDirection: 'column', gap: 6,
      minHeight: 70,
      position: 'relative',
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
        <div style={{
          width: 22, height: 22, borderRadius: 6, flexShrink: 0,
          background: isDone ? 'var(--accent)' : isNow ? 'var(--accent)' : 'var(--surface-2)',
          color: isDone || isNow ? '#fff' : 'var(--ink)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontSize: 11, fontFamily: 'var(--font-mono)',
        }}>
          {isDone ? <Ico.check style={{width:11, height:11}}/> : (MODULE_ICONS[name] || '○')}
        </div>
        <div style={{
          fontSize: 11.5, fontWeight: 600, letterSpacing: '-0.005em',
          color: isNow ? 'var(--accent-ink)' : 'var(--ink)',
          whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis',
          flex: 1, minWidth: 0,
        }}>{name.replace(' module', '')}</div>
      </div>
      <div style={{
        display: 'flex', alignItems: 'center', gap: 6,
        fontSize: 9.5, fontFamily: 'var(--font-mono)',
        color: isNow ? 'var(--accent-ink)' : 'var(--muted)',
        opacity: isNow ? 0.85 : 1,
      }}>
        {isDone ? 'SOLVED' :
          isNow ? <><span style={{width:5,height:5,borderRadius:99,background:'var(--accent)',display:'inline-block'}}/>NOW · {progress}/{total}</> :
          `${total} steps · ~${total <= 3 ? '1' : total <= 5 ? '2' : '3'}m`}
      </div>
    </button>
  );
}

window.ModuleCard = ModuleCard;
