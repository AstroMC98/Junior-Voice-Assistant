// Discover (catalog) + Library screens

function ScreenDiscover({ onOpenGuide, onCategoryFilter }) {
  const [category, setCategory] = React.useState('all');
  const [search, setSearch] = React.useState('');

  const filtered = GUIDES.filter(g =>
    (category === 'all' || g.category === category) &&
    (search === '' || g.title.toLowerCase().includes(search.toLowerCase()))
  );

  const featured = GUIDES.filter(g => g.featured);

  // group by category for rails
  const byCat = {};
  CATEGORIES.forEach(c => { byCat[c.id] = GUIDES.filter(g => g.category === c.id); });

  return (
    <div className="app-scroll">
      <ScreenHeader
        title="Discover"
        sub="Voice-ready guides from the community"
        right={
          <button style={{
            width: 40, height: 40, borderRadius: 99,
            background: 'var(--surface-2)', border: '1px solid var(--border)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}><Ico.bell /></button>
        }
      />

      {/* search */}
      <div style={{ padding: '0 20px 16px' }}>
        <div className="field" style={{ background: 'var(--surface-2)', border: 0 }}>
          <Ico.search style={{ color: 'var(--muted)' }}/>
          <input placeholder="Search recipes, manuals, modules…" value={search} onChange={e=>setSearch(e.target.value)}/>
          <span className="kbd">⌘K</span>
        </div>
      </div>

      {/* category rail */}
      <div className="rail" style={{ paddingBottom: 4 }}>
        <button className={`chip ${category === 'all' ? 'chip-active' : ''}`}
          onClick={() => setCategory('all')}
          style={{ height: 36, padding: '0 14px', fontSize: 13.5, fontWeight: 500 }}>
          ✨ All
        </button>
        {CATEGORIES.map(c => (
          <CategoryPill key={c.id} cat={c} active={category === c.id} onClick={() => setCategory(c.id)} />
        ))}
      </div>

      {/* featured hero */}
      {category === 'all' && search === '' && (
        <>
          <div className="sec-title">
            <h2>Featured</h2>
            <button className="more">See all</button>
          </div>
          <div style={{ padding: '0 20px' }}>
            <FeaturedHero guide={featured[0]} onClick={() => onOpenGuide(featured[0])} />
          </div>
        </>
      )}

      {/* if filtered → grid; otherwise rails per category */}
      {(category !== 'all' || search !== '') ? (
        <>
          <div className="sec-title">
            <h2>{search ? `Results (${filtered.length})` : CATEGORIES.find(c=>c.id===category)?.label}</h2>
          </div>
          <div style={{ padding: '0 20px', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
            {filtered.map(g => (
              <GridCard key={g.id} guide={g} onClick={() => onOpenGuide(g)} />
            ))}
            {filtered.length === 0 && <div style={{color:'var(--muted)'}}>No guides match.</div>}
          </div>
        </>
      ) : (
        <>
          {CATEGORIES.slice(0, 4).map(c => byCat[c.id].length > 0 && (
            <React.Fragment key={c.id}>
              <div className="sec-title">
                <h2>
                  <span style={{ marginRight: 6 }}>{c.emoji}</span>{c.label}
                </h2>
                <button className="more" onClick={() => setCategory(c.id)}>See all →</button>
              </div>
              <div className="rail">
                {byCat[c.id].map(g => (
                  <GuideCardLarge key={g.id} guide={g} onClick={() => onOpenGuide(g)} />
                ))}
              </div>
            </React.Fragment>
          ))}

          {/* trending */}
          <div className="sec-title" style={{ marginTop: 28 }}>
            <h2>Trending this week</h2>
          </div>
          <div style={{ padding: '0 20px', display: 'flex', flexDirection: 'column', gap: 10 }}>
            {GUIDES.slice(2, 6).map(g => (
              <GuideCardSmall key={g.id} guide={g} onClick={() => onOpenGuide(g)} />
            ))}
          </div>
        </>
      )}

      <div style={{ height: 24 }}/>
    </div>
  );
}

function FeaturedHero({ guide, onClick }) {
  return (
    <button onClick={onClick} style={{
      width: '100%', height: 240, borderRadius: 22,
      background: guide.bg, position: 'relative', overflow: 'hidden',
      textAlign: 'left', padding: 0, boxShadow: 'var(--shadow-card)',
    }}>
      <div style={{
        position: 'absolute', inset: 0,
        background: 'linear-gradient(180deg, transparent 30%, rgba(0,0,0,0.78))',
      }}/>
      <div style={{ position: 'absolute', top: 18, left: 18, right: 18, display: 'flex', justifyContent: 'space-between' }}>
        <div style={{
          background: 'rgba(255,255,255,0.18)', backdropFilter: 'blur(10px)',
          padding: '4px 10px', borderRadius: 99,
          color: '#fff', fontSize: 11, fontWeight: 600, letterSpacing: 0.06,
        }} className="mono">FEATURED</div>
        <div style={{
          background: 'rgba(0,0,0,0.3)', backdropFilter: 'blur(10px)',
          padding: '4px 10px', borderRadius: 99,
          color: '#fff', fontSize: 12, display: 'flex', gap: 4, alignItems: 'center',
        }}>
          <Ico.star style={{ width: 13, height: 13 }}/> {guide.rating} · {(guide.runs/1000).toFixed(1)}k runs
        </div>
      </div>
      <div style={{
        position: 'absolute', top: 60, left: 18, fontSize: 56, lineHeight: 1,
        filter: 'drop-shadow(0 4px 12px rgba(0,0,0,0.4))',
      }}>{guide.glyph}</div>
      <div style={{
        position: 'absolute', bottom: 18, left: 18, right: 18, color: '#fff',
      }}>
        <div style={{ fontSize: 11, opacity: 0.85, marginBottom: 4 }} className="mono">
          {guide.stepsCount} STEPS · {guide.duration.toUpperCase()}
        </div>
        <div style={{ fontSize: 22, fontWeight: 600, letterSpacing: '-0.015em', lineHeight: 1.1 }}>
          {guide.title}
        </div>
        <div style={{ fontSize: 13, opacity: 0.85, marginTop: 6, maxWidth: 280 }}>
          {guide.subtitle}
        </div>
      </div>
    </button>
  );
}

function GridCard({ guide, onClick }) {
  return (
    <button onClick={onClick} style={{ textAlign: 'left', padding: 0, background: 'transparent' }}>
      <div style={{
        width: '100%', aspectRatio: '1 / 1', borderRadius: 16,
        background: guide.bg, position: 'relative', overflow: 'hidden',
        boxShadow: 'var(--shadow-card)',
      }}>
        <div style={{
          position: 'absolute', inset: 0,
          background: 'linear-gradient(180deg, transparent 50%, rgba(0,0,0,0.55))',
        }}/>
        <div style={{ position: 'absolute', top: 10, left: 10, fontSize: 24,
          filter: 'drop-shadow(0 2px 6px rgba(0,0,0,0.3))' }}>{guide.glyph}</div>
        <div style={{
          position: 'absolute', bottom: 10, left: 10, right: 10, color: '#fff',
        }}>
          <div style={{ fontSize: 10, opacity: 0.85, marginBottom: 2 }} className="mono">
            {guide.stepsCount} STEPS
          </div>
          <div style={{ fontSize: 13, fontWeight: 600, letterSpacing: '-0.01em', lineHeight: 1.15 }}>
            {guide.title}
          </div>
        </div>
      </div>
    </button>
  );
}

// ─── Library ────────────────────────────────────────────────
function ScreenLibrary({ onOpenGuide, onCreate }) {
  const [tab, setTab] = React.useState('mine');
  const tabs = [
    { id: 'mine',   label: 'My guides', n: 8 },
    { id: 'forks',  label: 'Forks',     n: 14 },
    { id: 'saved',  label: 'Saved',     n: 23 },
  ];
  const items = GUIDES;

  return (
    <div className="app-scroll">
      <ScreenHeader
        title="Library"
        sub="Your guides, forks, and saves"
        right={
          <button onClick={onCreate} className="btn btn-sm" style={{ background: 'var(--accent)', color: '#fff' }}>
            <Ico.plus style={{width:16,height:16}}/> New
          </button>
        }
      />

      {/* tabs */}
      <div style={{ padding: '0 20px 16px' }}>
        <div className="seg" style={{ width: '100%', display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)' }}>
          {tabs.map(t => (
            <button key={t.id} className={tab === t.id ? 'on' : ''} onClick={() => setTab(t.id)} style={{ width: '100%' }}>
              {t.label} <span style={{ color: 'var(--muted-2)', marginLeft: 4, fontWeight: 500 }}>{t.n}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Stats summary */}
      <div style={{ padding: '0 20px 20px', display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 8 }}>
        {[
          { l: 'Sessions',  v: '47',   d: 'this month' },
          { l: 'Avg. time', v: '12m',  d: 'per session' },
          { l: 'Streak',    v: '6 d',  d: '🔥 active' },
        ].map((s, i) => (
          <div key={i} className="card card-pad" style={{ padding: 12 }}>
            <div style={{ fontSize: 11, color: 'var(--muted)', textTransform: 'uppercase', letterSpacing: 0.04 }} className="mono">{s.l}</div>
            <div style={{ fontSize: 22, fontWeight: 600, letterSpacing: '-0.02em', marginTop: 4 }}>{s.v}</div>
            <div style={{ fontSize: 11, color: 'var(--muted-2)' }}>{s.d}</div>
          </div>
        ))}
      </div>

      <div className="sec-title">
        <h2>
          {tab === 'mine' && 'Created by you'}
          {tab === 'forks' && 'Forked from others'}
          {tab === 'saved' && 'Saved for later'}
        </h2>
      </div>

      <div style={{ padding: '0 20px', display: 'flex', flexDirection: 'column', gap: 10 }}>
        {items.slice(0, 6).map(g => (
          <LibraryRow key={g.id} guide={g} mine={tab === 'mine'} onClick={() => onOpenGuide(g)} />
        ))}
      </div>

      <div style={{ height: 32 }}/>
    </div>
  );
}

function LibraryRow({ guide, mine, onClick }) {
  return (
    <button onClick={onClick} style={{
      width: '100%', textAlign: 'left', padding: 12,
      background: 'var(--surface)', border: '1px solid var(--border)',
      borderRadius: 16, display: 'flex', gap: 12, alignItems: 'center',
    }}>
      <div style={{
        width: 60, height: 60, borderRadius: 12, background: guide.bg,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontSize: 28, flexShrink: 0, position: 'relative', overflow: 'hidden',
      }}>{guide.glyph}</div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: 14.5, fontWeight: 600, letterSpacing: '-0.01em', lineHeight: 1.2, color: 'var(--ink)' }}>
          {guide.title}
        </div>
        <div style={{ fontSize: 12, color: 'var(--muted)', marginTop: 4, display: 'flex', gap: 6, alignItems: 'center' }}>
          <span className="tag" style={{ padding: '2px 6px', fontSize: 9.5 }}>{guide.category.toUpperCase()}</span>
          <span>{guide.stepsCount} steps</span>
          <span>·</span>
          <span>{guide.duration}</span>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 4, marginTop: 6 }}>
          <div style={{
            flex: 1, height: 3, borderRadius: 99, background: 'var(--surface-3)',
            overflow: 'hidden', maxWidth: 100,
          }}>
            <div style={{
              height: '100%', width: `${30 + (guide.id.length * 7) % 60}%`,
              background: 'var(--accent)',
            }}/>
          </div>
          <span style={{ fontSize: 10, color: 'var(--muted-2)' }} className="mono">
            LAST RUN · 2d AGO
          </span>
        </div>
      </div>
      <Ico.more style={{ color: 'var(--muted-2)' }}/>
    </button>
  );
}

Object.assign(window, { ScreenDiscover, ScreenLibrary });
