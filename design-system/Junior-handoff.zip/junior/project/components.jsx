// Icons + shared components for Junior

// ─── Icons (24x24 stroke, currentColor) ────────────────────────
const Ico = {
  home:     (p) => <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M3 11l9-8 9 8v9a2 2 0 0 1-2 2h-4v-6h-6v6H5a2 2 0 0 1-2-2z"/></svg>,
  library:  (p) => <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M4 4h6v16H4zM14 4h2v16h-2zM18 4l4 14"/></svg>,
  plus:     (p) => <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" {...p}><path d="M12 5v14M5 12h14"/></svg>,
  team:     (p) => <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><circle cx="9" cy="8" r="3.2"/><path d="M3 20c0-3.3 2.7-6 6-6s6 2.7 6 6"/><circle cx="17" cy="9" r="2.5"/><path d="M15 14c2.8 0 6 1.5 6 5"/></svg>,
  user:     (p) => <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><circle cx="12" cy="8" r="4"/><path d="M4 21c0-4.4 3.6-8 8-8s8 3.6 8 8"/></svg>,
  search:   (p) => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" {...p}><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>,
  mic:      (p) => <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><rect x="9" y="3" width="6" height="12" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/></svg>,
  micFill:  (p) => <svg width="28" height="28" viewBox="0 0 24 24" fill="currentColor" {...p}><rect x="9" y="3" width="6" height="12" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3" stroke="currentColor" strokeWidth="2" fill="none" strokeLinecap="round"/></svg>,
  pause:    (p) => <svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor" {...p}><rect x="6" y="5" width="4" height="14" rx="1"/><rect x="14" y="5" width="4" height="14" rx="1"/></svg>,
  camera:   (p) => <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M3 7h4l1.5-2h7L17 7h4v12H3z"/><circle cx="12" cy="13" r="4"/></svg>,
  close:    (p) => <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" {...p}><path d="M6 6l12 12M18 6 6 18"/></svg>,
  chev:     (p) => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="m9 6 6 6-6 6"/></svg>,
  chevL:    (p) => <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="m15 6-6 6 6 6"/></svg>,
  more:     (p) => <svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor" {...p}><circle cx="5" cy="12" r="1.6"/><circle cx="12" cy="12" r="1.6"/><circle cx="19" cy="12" r="1.6"/></svg>,
  fork:     (p) => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><circle cx="6" cy="6" r="2"/><circle cx="18" cy="6" r="2"/><circle cx="12" cy="18" r="2"/><path d="M6 8v2a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V8M12 12v4"/></svg>,
  star:     (p) => <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" {...p}><path d="M12 2l3.1 6.3 6.9 1-5 4.9 1.2 6.8L12 17.8 5.8 21l1.2-6.8-5-4.9 6.9-1z"/></svg>,
  clock:    (p) => <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>,
  pdf:      (p) => <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M14 3H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"/><path d="M14 3v6h6"/></svg>,
  link:     (p) => <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M10 14a5 5 0 0 0 7 0l3-3a5 5 0 0 0-7-7l-1 1"/><path d="M14 10a5 5 0 0 0-7 0l-3 3a5 5 0 0 0 7 7l1-1"/></svg>,
  cam:      (p) => <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M3 7h4l1.5-2h7L17 7h4v12H3z"/><circle cx="12" cy="13" r="4"/></svg>,
  share:    (p) => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><circle cx="6" cy="12" r="2.5"/><circle cx="18" cy="6" r="2.5"/><circle cx="18" cy="18" r="2.5"/><path d="m8 11 8-4M8 13l8 4"/></svg>,
  play:     (p) => <svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor" {...p}><path d="M7 4v16l13-8z"/></svg>,
  bell:     (p) => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M6 8a6 6 0 1 1 12 0v4l2 3H4l2-3z"/><path d="M9 18a3 3 0 0 0 6 0"/></svg>,
  setting:  (p) => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><circle cx="12" cy="12" r="3"/><path d="M19 15l-1.5-.7M6.5 9.7 5 9m14 0-1.5.7M6.5 14.3 5 15m7-12v2m0 14v2m7-9h-2M5 12H3"/></svg>,
  check:    (p) => <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="m5 12 5 5 9-11"/></svg>,
  list:     (p) => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" {...p}><path d="M4 6h16M4 12h16M4 18h12"/></svg>,
  sun:      (p) => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" {...p}><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></svg>,
  moon:     (p) => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M20 14A8 8 0 0 1 10 4a8 8 0 1 0 10 10z"/></svg>,
  wave:     (p) => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" {...p}><path d="M2 12h2m4 0v-6m4 6v-9m4 9v-5m4 5v-3m2 3h-2"/></svg>,
  arrow:    (p) => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="m5 12 14 0M13 6l6 6-6 6"/></svg>,
  google:   (p) => <svg width="20" height="20" viewBox="0 0 24 24" {...p}><path fill="#4285F4" d="M23 12.3c0-.8-.1-1.6-.2-2.3H12v4.4h6.2c-.3 1.5-1.1 2.8-2.3 3.6v3h3.7c2.2-2 3.4-5 3.4-8.7z"/><path fill="#34A853" d="M12 24c3.1 0 5.7-1 7.6-2.8l-3.7-2.9c-1 .7-2.3 1.1-3.9 1.1-3 0-5.5-2-6.4-4.7H1.8v3C3.6 21.4 7.5 24 12 24z"/><path fill="#FBBC04" d="M5.6 14.6c-.5-1.5-.5-3.1 0-4.6V7H1.8c-1.6 3.2-1.6 7 0 10.1l3.8-2.5z"/><path fill="#EA4335" d="M12 4.8c1.7 0 3.2.6 4.3 1.7l3.3-3.3C17.7 1.2 15.1 0 12 0 7.5 0 3.6 2.6 1.8 6.4l3.8 3c.9-2.7 3.4-4.6 6.4-4.6z"/></svg>,
  apple:    (p) => <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" {...p}><path d="M17.5 12.8c0-2.8 2.3-4.1 2.4-4.2-1.3-1.9-3.4-2.2-4.1-2.2-1.7-.2-3.4 1-4.3 1-.9 0-2.3-1-3.8-1-1.9 0-3.7 1.1-4.7 2.9-2 3.5-.5 8.6 1.4 11.4 1 1.4 2.1 2.9 3.6 2.9 1.4-.1 2-.9 3.7-.9 1.7 0 2.2.9 3.7.9 1.5 0 2.5-1.4 3.5-2.8 1.1-1.6 1.5-3.1 1.5-3.2-.1 0-2.9-1.1-2.9-4.8zM14.7 4.6c.8-.9 1.3-2.2 1.1-3.5-1.1.1-2.5.8-3.3 1.7-.7.8-1.4 2.1-1.2 3.4 1.2.1 2.4-.7 3.4-1.6z"/></svg>,
  spark:    (p) => <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" {...p}><path d="M12 2l2 7 7 2-7 2-2 7-2-7-7-2 7-2z"/></svg>,
  trash:    (p) => <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13M10 11v6M14 11v6"/></svg>,
  send:     (p) => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M22 2 11 13M22 2l-7 20-4-9-9-4z"/></svg>,
};

// ─── Avatar ────────────────────────────────────────────────────
function Avatar({ name, initials, color, size = 32, ring = false }) {
  const ini = initials || (name ? name.split(' ').map(s => s[0]).slice(0,2).join('') : '?');
  return (
    <div className="avatar" style={{
      width: size, height: size, fontSize: size * 0.36,
      background: color || 'var(--surface-2)',
      color: '#fff',
      border: ring ? '2px solid var(--surface)' : '1px solid var(--border)',
      boxShadow: ring ? '0 0 0 1px var(--border)' : 'none',
    }}>{ini}</div>
  );
}

// ─── Status bar (custom — matches our theme) ──────────────────
function StatusBar({ dark }) {
  const c = dark ? '#fff' : '#15120D';
  return (
    <div style={{
      position: 'absolute', top: 0, left: 0, right: 0,
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      padding: '18px 28px 8px', zIndex: 30,
      color: c, pointerEvents: 'none',
    }}>
      <div style={{ fontWeight: 600, fontSize: 15 }}>9:41</div>
      <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
        <svg width="17" height="11" viewBox="0 0 17 11" fill="currentColor"><rect x="0" y="6" width="3" height="4" rx="0.6"/><rect x="4.5" y="4" width="3" height="6" rx="0.6"/><rect x="9" y="2" width="3" height="8" rx="0.6"/><rect x="13.5" y="0" width="3" height="10" rx="0.6"/></svg>
        <svg width="24" height="12" viewBox="0 0 24 12" fill="none" stroke="currentColor"><rect x="0.5" y="0.5" width="21" height="11" rx="3"/><rect x="2" y="2" width="18" height="8" rx="1.5" fill="currentColor"/><rect x="22" y="4" width="1.5" height="4" rx="0.5" fill="currentColor"/></svg>
      </div>
    </div>
  );
}

// ─── Bottom tab bar ───────────────────────────────────────────
function TabBar({ active, onChange }) {
  const tabs = [
    { id: 'discover', label: 'Discover', icon: Ico.home },
    { id: 'library',  label: 'Library',  icon: Ico.library },
    { id: 'create',   label: 'Create',   icon: Ico.plus, fab: true },
    { id: 'team',     label: 'Team',     icon: Ico.team },
    { id: 'profile',  label: 'Profile',  icon: Ico.user },
  ];
  return (
    <div className="tabbar">
      {tabs.map(t => (
        <button key={t.id} className={`tab ${active === t.id ? 'active' : ''}`} onClick={() => onChange(t.id)}>
          {t.fab ? (
            <div style={{
              width: 40, height: 40, borderRadius: 14,
              background: 'var(--accent)', color: '#fff',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              boxShadow: '0 4px 12px color-mix(in oklab, var(--accent) 40%, transparent)',
              marginTop: -8, marginBottom: 4,
            }}>
              <Ico.plus />
            </div>
          ) : (
            <div className="tab-ico"><t.icon /></div>
          )}
          <div>{t.label}</div>
        </button>
      ))}
    </div>
  );
}

// ─── Category pill ────────────────────────────────────────────
function CategoryPill({ cat, active, onClick }) {
  return (
    <button className={`chip ${active ? 'chip-active' : ''}`} onClick={onClick}
      style={{ height: 36, padding: '0 14px', fontSize: 13.5, fontWeight: 500 }}>
      <span style={{ fontSize: 15, marginRight: 2 }}>{cat.emoji}</span> {cat.label}
    </button>
  );
}

// ─── Guide card (large, for rails) ────────────────────────────
function GuideCardLarge({ guide, onClick }) {
  return (
    <button onClick={onClick} className="fade-in" style={{
      width: 220, textAlign: 'left',
      background: 'transparent', padding: 0,
    }}>
      <div style={{
        width: 220, height: 160, borderRadius: 18,
        background: guide.bg,
        position: 'relative', overflow: 'hidden',
        boxShadow: 'var(--shadow-card)',
      }}>
        <div style={{
          position: 'absolute', inset: 0,
          background: 'linear-gradient(180deg, transparent 50%, rgba(0,0,0,0.55))',
        }} />
        <div style={{
          position: 'absolute', top: 12, left: 12,
          fontSize: 32, lineHeight: 1, filter: 'drop-shadow(0 2px 8px rgba(0,0,0,0.3))',
        }}>{guide.glyph}</div>
        <div style={{
          position: 'absolute', top: 12, right: 12,
          display: 'flex', gap: 4, alignItems: 'center',
          color: '#fff', fontSize: 11, fontWeight: 500,
          background: 'rgba(0,0,0,0.25)', backdropFilter: 'blur(8px)',
          padding: '4px 8px', borderRadius: 99,
        }}>
          <Ico.star style={{width:12, height:12}} /> {guide.rating}
        </div>
        <div style={{
          position: 'absolute', bottom: 10, left: 12, right: 12, color: '#fff',
        }}>
          <div style={{ fontSize: 11, fontWeight: 500, opacity: 0.9, letterSpacing: 0.02 }} className="mono">
            {guide.stepsCount} STEPS · {guide.duration}
          </div>
        </div>
      </div>
      <div style={{ padding: '10px 4px 0' }}>
        <div style={{ fontWeight: 600, fontSize: 14.5, letterSpacing: '-0.01em', lineHeight: 1.2, color: 'var(--ink)' }}>
          {guide.title}
        </div>
        <div style={{ fontSize: 12, color: 'var(--muted)', marginTop: 3, display: 'flex', alignItems: 'center', gap: 6 }}>
          <Avatar size={16} initials={guide.author.initials} color={guide.author.avatar} />
          {guide.author.name}
        </div>
      </div>
    </button>
  );
}

// ─── Guide card (small, square — featured) ─────────────────────
function GuideCardSmall({ guide, onClick }) {
  return (
    <button onClick={onClick} style={{
      width: '100%', textAlign: 'left', padding: 10,
      background: 'var(--surface)', border: '1px solid var(--border)',
      borderRadius: 16, display: 'flex', gap: 10, alignItems: 'center',
    }}>
      <div style={{
        width: 56, height: 56, borderRadius: 12, background: guide.bg,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontSize: 24, flexShrink: 0,
      }}>{guide.glyph}</div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontWeight: 600, fontSize: 14, letterSpacing: '-0.01em', lineHeight: 1.2, color: 'var(--ink)' }}>
          {guide.title}
        </div>
        <div style={{ fontSize: 12, color: 'var(--muted)', marginTop: 4, display: 'flex', gap: 8 }}>
          <span style={{display:'inline-flex',alignItems:'center',gap:3}}><Ico.clock />{guide.duration}</span>
          <span>·</span>
          <span>{guide.stepsCount} steps</span>
        </div>
      </div>
      <Ico.chev style={{ color: 'var(--muted-2)' }} />
    </button>
  );
}

// ─── Live waveform (animated bars; reacts to listening state) ──
function Waveform({ active = true, style = 'bars', height = 36, color, bars = 28 }) {
  const [seed, setSeed] = React.useState(0);
  React.useEffect(() => {
    if (!active) return;
    const id = setInterval(() => setSeed(s => s + 1), 90);
    return () => clearInterval(id);
  }, [active]);

  const c = color || 'var(--accent)';

  if (style === 'ring') {
    return (
      <div style={{ position: 'relative', width: height * 3, height, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        {[0,1,2].map(i => (
          <div key={i} style={{
            position: 'absolute', borderRadius: '50%',
            width: height + i*14, height: height + i*14,
            border: `2px solid ${c}`,
            opacity: active ? 0.7 - i*0.2 : 0.15,
            transform: active ? `scale(${1 + Math.sin((seed + i*3)/3)*0.06})` : 'scale(1)',
            transition: 'transform 0.2s ease-out',
          }}/>
        ))}
      </div>
    );
  }

  if (style === 'line') {
    const pts = [...Array(bars)].map((_, i) => {
      const v = active ? (Math.sin((seed + i*7)/3) * 0.5 + Math.sin((seed + i*2)/5) * 0.4) : 0;
      return `${(i/(bars-1))*100},${50 + v*40}`;
    });
    return (
      <svg width="100%" height={height} viewBox="0 0 100 100" preserveAspectRatio="none">
        <polyline points={pts.join(' ')} fill="none" stroke={c} strokeWidth="2" strokeLinejoin="round" strokeLinecap="round" />
      </svg>
    );
  }

  // bars (default)
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 3,
      height, width: '100%', justifyContent: 'center',
    }}>
      {[...Array(bars)].map((_, i) => {
        const mid = bars / 2;
        const d = Math.abs(i - mid) / mid;
        const base = (1 - d * 0.6);
        const v = active
          ? base * (0.3 + Math.abs(Math.sin((seed + i * 1.7) / 2.6)) * 0.7 + Math.sin((seed + i)/4) * 0.15)
          : 0.12;
        return (
          <div key={i} style={{
            width: 3, height: '100%',
            background: c,
            borderRadius: 99,
            transform: `scaleY(${Math.max(0.08, Math.min(1, v))})`,
            transition: 'transform 0.12s cubic-bezier(0.4,0,0.2,1)',
            opacity: active ? 1 : 0.45,
          }}/>
        );
      })}
    </div>
  );
}

// ─── Step progress dots ──────────────────────────────────────
function StepProgress({ total, current }) {
  return (
    <div style={{ display: 'flex', gap: 4, padding: '0 0' }}>
      {[...Array(total)].map((_, i) => (
        <div key={i} style={{
          flex: 1, height: 4, borderRadius: 99,
          background: i < current ? 'var(--accent)' : i === current ? 'var(--accent)' : 'var(--border)',
          opacity: i <= current ? 1 : 1,
        }}/>
      ))}
    </div>
  );
}

// ─── Faux generated step image ───────────────────────────────
function StepImage({ guide, step, showCrop = true, height = 200 }) {
  // Render a stylized "page from the guide" using divs to mimic a diagram
  return (
    <div style={{
      position: 'relative', width: '100%', height,
      borderRadius: 18, overflow: 'hidden',
      background: 'var(--surface-2)',
      border: '1px solid var(--border)',
    }}>
      <div style={{
        position: 'absolute', inset: 0,
        background: guide.bg, opacity: 0.18,
      }}/>
      {/* fake page content */}
      <div style={{ position: 'absolute', inset: 0, padding: 18, fontFamily: 'var(--font-mono)', fontSize: 9, color: 'var(--ink-2)', opacity: 0.45 }}>
        <div style={{ fontWeight: 700, fontSize: 11, letterSpacing: 0.04, textTransform: 'uppercase', marginBottom: 8 }}>
          {guide.sourceLabel || 'Source'} — p.{Math.max(1, step.i)}
        </div>
        <div style={{ height: 4, width: '40%', background: 'currentColor', opacity: 0.5, marginBottom: 6 }}/>
        <div style={{ height: 4, width: '70%', background: 'currentColor', opacity: 0.3, marginBottom: 6 }}/>
        <div style={{ height: 4, width: '55%', background: 'currentColor', opacity: 0.3, marginBottom: 16 }}/>

        {/* simulated diagram — wires for KTANE, otherwise abstract */}
        {guide.id === 'g_ktane' ? (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 9, padding: '6px 0' }}>
            {['#e63946','#3a86ff','#3a86ff','#ffd60a','#e63946','#fafafa'].map((c, i) => (
              <div key={i} style={{ height: 6, width: '85%', background: c, borderRadius: 99, opacity: 0.9 }}/>
            ))}
          </div>
        ) : (
          <div style={{ marginTop: 8, display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 6 }}>
            {[...Array(8)].map((_,i)=>(
              <div key={i} style={{ aspectRatio: '1', borderRadius: 4, background: 'currentColor', opacity: 0.06 + (i%3)*0.04 }}/>
            ))}
          </div>
        )}
      </div>

      {/* AI crop overlay */}
      {showCrop && (
        <div className="crop-box" style={{
          left: '8%', top: '38%', width: '78%', height: '42%',
        }}>
          <div className="crop-label">AI crop · step {step.i}</div>
        </div>
      )}
    </div>
  );
}

// ─── Sheet (bottom modal) ────────────────────────────────────
function Sheet({ open, onClose, children, height }) {
  if (!open) return null;
  return (
    <>
      <div className="sheet-back" onClick={onClose} />
      <div className="sheet" style={{ height }}>
        <div className="sheet-handle" />
        {children}
      </div>
    </>
  );
}

// ─── Header ───────────────────────────────────────────────────
function ScreenHeader({ title, sub, right, left }) {
  return (
    <div className="app-header">
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          {left}
          <h1 style={{ whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{title}</h1>
        </div>
        {sub && <div className="h-sub">{sub}</div>}
      </div>
      {right && <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>{right}</div>}
    </div>
  );
}

Object.assign(window, {
  Ico, Avatar, StatusBar, TabBar, CategoryPill, GuideCardLarge, GuideCardSmall,
  Waveform, StepProgress, StepImage, Sheet, ScreenHeader,
});
